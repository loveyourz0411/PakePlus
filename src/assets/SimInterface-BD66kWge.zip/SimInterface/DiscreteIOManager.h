

#pragma once
#include "DiscreteMessage.h"
#include "DiscreteAPeriodic.h"
#include "DiscretePeriodic.h"
#include "VIPBaseTypes.h"
#include <iostream>
#include <vector>

class DiscreteIOManager
{
    private:
        std::vector<DiscretePeriodic*>* m_PeriodicMessages;
        std::vector<DiscreteAPeriodic*>* m_APeriodicMessages;

    protected:
        VIP_ParticipantHandle m_ParticipantHandle;
                    
        ////////////////////////////////////////////////////////////////////////////////////////////
        // addPeriodicMessage
        //
        /// <summary>
        /// Add periodic message to internal list
        /// </summary>
        void addPeriodicMessage(DiscretePeriodic* aMessage);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addAPeriodicMessage
        //
        /// <summary>
        /// Add APeriodic message to internal list
        /// </summary>
        void addAPeriodicMessage(DiscreteAPeriodic* aMessage);
        
    public:
        DiscreteIOManager(VIP_ParticipantHandle aParticipantHandle);
        ~DiscreteIOManager();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupIO
        //
        /// <summary>
        /// setupMessages virtual function used to setup the messages
        /// </summary>
        virtual VIP_Result setupMessages() = 0;

        ////////////////////////////////////////////////////////////////////////////////////////////
        // Receive
        //
        /// <summary>
        /// Receives all the Discrete messages
        /// If an error is returned by one of the messages the method returns immediatley with the
        /// VIP result error.
        /// Therfore it will not attempt to receive the rest of the discrete messages in the list.
        /// If all the discretes were received without error (even if no new data was received) the
        /// method returns VIP_Success
        /// </summary>
        /// <returns>A VIP_Result value</returns>
        /// <list> 
        /// <item>VIP_Success - All discretes were received The operation completed successfully.</item>
        /// <item>VIP_BadHandle - A discrete handle was invalid.</item>
        /// <item>VIP_InvalidOperation - The discrete is not published, or is periodic</item>
        /// </list>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send Messages
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startAllPeriodics
        //
        /// <summary>
        /// Starts all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result startAllPeriodics();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopAllPeriodics
        //
        /// <summary>
        /// Stops all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result stopAllPeriodics();
};