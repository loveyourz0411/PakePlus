#include "A825Parameter.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Bool A825Parameter<VIP_Bool, VIP_Type_Bool>::getValue()
{
    VIP_Bool lValue = false;
    VIP825_GetValueBool(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Bool, VIP_Type_Bool>::setValue(VIP_Bool aValue)
{
    return VIP825_SetValueBool(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Char parameter
/// </summary>
template<>
VIP_Int8 A825Parameter<VIP_Int8, VIP_Type_Int8>::getValue()
{
    VIP_Int8 lValue = 0;
    VIP825_GetValueChar(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Char parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Int8, VIP_Type_Int8>::setValue(VIP_Int8 aValue)
{
    return VIP825_SetValueChar(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int8 parameter
/// </summary>
template<>
VIP_UInt8 A825Parameter<VIP_UInt8, VIP_Type_UInt8>::getValue()
{
    VIP_UInt8 lValue = 0;
    VIP825_GetValueUInt8(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int8 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_UInt8, VIP_Type_UInt8>::setValue(VIP_UInt8 aValue)
{
    return VIP825_SetValueUInt8(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int16 parameter
/// </summary>
template<>
VIP_Int16 A825Parameter<VIP_Int16, VIP_Type_Int16>::getValue()
{
    VIP_Int16 lValue = 0;
    VIP825_GetValueInt16(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int16 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Int16, VIP_Type_Int16>::setValue(VIP_Int16 aValue)
{
    return VIP825_SetValueInt16(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_UInt16 parameter
/// </summary>
template<>
VIP_UInt16 A825Parameter<VIP_UInt16, VIP_Type_UInt16>::getValue()
{
    VIP_UInt16 lValue = 0;
    VIP825_GetValueUInt16(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_UInt16 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_UInt16, VIP_Type_UInt16>::setValue(VIP_UInt16 aValue)
{
    return VIP825_SetValueUInt16(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Int32 A825Parameter<VIP_Int32, VIP_Type_Int32>::getValue()
{
    VIP_Int32 lValue = 0;
    VIP825_GetValueInt32(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Int32, VIP_Type_Int32>::setValue(VIP_Int32 aValue)
{
    return VIP825_SetValueInt32(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_UInt32 parameter
/// </summary>
template<>
VIP_UInt32 A825Parameter<VIP_UInt32, VIP_Type_UInt32>::getValue()
{
    VIP_UInt32 lValue = 0;
    VIP825_GetValueUInt32(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_UInt32 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_UInt32, VIP_Type_UInt32>::setValue(VIP_UInt32 aValue)
{
    return VIP825_SetValueUInt32(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int64 parameter
/// </summary>
template<>
VIP_Int64 A825Parameter<VIP_Int64, VIP_Type_Int64>::getValue()
{
    VIP_Int64 lValue = 0;
    VIP825_GetValueInt64(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int64 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Int64, VIP_Type_Int64>::setValue(VIP_Int64 aValue)
{
    return VIP825_SetValueInt64(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_UInt64 parameter
/// </summary>
template<>
VIP_UInt64 A825Parameter<VIP_UInt64, VIP_Type_UInt64>::getValue()
{
    VIP_UInt64 lValue = 0;
    VIP825_GetValueUInt64(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_UInt64 parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_UInt64, VIP_Type_UInt64>::setValue(VIP_UInt64 aValue)
{
    return VIP825_SetValueUInt64(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Float A825Parameter<VIP_Float, VIP_Type_Float>::getValue()
{
    VIP_Float lValue = 0.0;
    VIP825_GetValueFloat(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Float, VIP_Type_Float>::setValue(VIP_Float aValue)
{
    return VIP825_SetValueFloat(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Double A825Parameter<VIP_Double, VIP_Type_Double>::getValue()
{
    VIP_Double lValue = 0.0;
    VIP825_GetValueDouble(getHandle(), &lValue);
    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Result A825Parameter<VIP_Double, VIP_Type_Double>::setValue(VIP_Double aValue)
{
    return VIP825_SetValueDouble(getHandle(), aValue);
}
