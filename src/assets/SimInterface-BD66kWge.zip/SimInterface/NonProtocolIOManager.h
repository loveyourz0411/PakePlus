

#pragma once
#include "NonProtocolMessage.h"
#include "NonProtocolAPeriodic.h"
#include "NonProtocolPeriodic.h"
#include "VIPBaseTypes.h"
#include <iostream>
#include <vector>

class NonProtocolDataIOManager
{
    private:
        std::vector<NonProtocolPeriodic*>* m_PeriodicMessages;
        std::vector<NonProtocolAPeriodic*>* m_APeriodicMessages;

    protected:
        VIP_ParticipantHandle m_ParticipantHandle;	
                    

        /// Add periodic message to internal list
        void addPeriodicMessage(NonProtocolPeriodic* aMessage);


        /// Add APeriodic message to internal list
        void addAPeriodicMessage(NonProtocolAPeriodic* aMessage);
        
    public:
        NonProtocolDataIOManager(VIP_ParticipantHandle aParticipantHandle);
        ~NonProtocolDataIOManager();


        /// setupIO virtual function used to setup the messages
        virtual VIP_Result setupIO() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Receive
        //
        /// <summary>
        /// Receives all the messages
        /// If an error is returned by one of the messages the method returns immediately with the
        /// VIP result error.
        /// Therefore it will not attempt to receive the rest of the messages in the list. If all
        /// the messages were received without error (even if no new data was received) the
        /// method returns VIP_Success
        /// </summary>
        /// <returns>A VIP_Result value</returns>
        /// <list> 
        /// <item>VIP_Success - All messages were received The operation completed 
        /// successfully.</item>
        /// <item>VIP_BadHandle - A message handle was invalid.</item>
        /// <item>VIP_InvalidOperation - The message is not published, or is periodic</item>
        /// </list>
        VIP_Result receive();

        /// Send NPD Messages
        VIP_Result send();

        /// Starts all the periodic messages (sending and receiving)
        VIP_Result startAllPeriodics();

        /// Stops all the periodic messages (sending and receiving)
        VIP_Result stopAllPeriodics();
};
