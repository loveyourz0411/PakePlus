

#pragma once

#include "A429WordBase.h"
#include "PeriodicBase.h"
#include <iostream>
#include <vector>

class Periodic : public PeriodicBase
{
    protected:
        A429WordBase* m_word;
        // Word Received flag used for freshness
        VIP_UInt8 m_receivedFlag;

    public:
        Periodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialisePeriodic
        //
        /// <summary>
        /// Initialise Periodic
        /// </summary>
        VIP_Result initialisePeriodic(A429WordBase* aWord);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setPeriod
        //
        /// <summary>
        /// Set Period
        /// </summary>
        VIP_Result setPeriod(VIP_UInt16 aPeriodMs);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodic
        //
        /// <summary>
        /// Stop sending periodic word
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodic
        //
        /// <summary>
        /// start sending periodic word
        /// </summary>
        VIP_Result startPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Word Receive Flag
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Word Receive Flag
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);
};