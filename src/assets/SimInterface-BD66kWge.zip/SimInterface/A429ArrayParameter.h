

#pragma once
#include "A429ParameterBase.h"
#include "VIPSimKernal.h"
#include "VIPSimA429.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class A429ArrayParameter : public A429ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A429ArrayParameter( VIP429_WordHandle aWordHandle, std::string aName, VIP429_ParameterType aParamType )
        : A429ParameterBase( aWordHandle, aName, aParamType )
    {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Get array from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result getArray( VIP_UInt32 aMaxLength, T* aData, VIP_UInt32* aDataLength );

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Set the 429 VIP array (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setArray( const T* aData, VIP_UInt32 aDataLength );
};