

#pragma once
#include "A429ParameterBase.h"
#include "VIPSimA429.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class A429Parameter : public A429ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A429Parameter(VIP429_WordHandle aWordHandle, std::string aParameterName,
                  VIP429_ParameterType aParamType)
        : A429ParameterBase(aWordHandle, aParameterName, aParamType)
    {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Get Value from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    T getValue();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Set the VIP value (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setValue(T aValue);
};
