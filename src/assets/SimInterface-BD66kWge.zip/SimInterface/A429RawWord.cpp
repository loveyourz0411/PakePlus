
#pragma once

#include "A429RawWord.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429RawWord::A429RawWord(VIP429_BusHandle aBusHandle, std::string aWordName)
    : A429WordBase(aBusHandle, aWordName)
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429RawWord::~A429RawWord()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A429RawWord::initialiseWord()
{
    VIP_Result lResult;

    // Create word to get handle
    lResult = VIP429_GetWord(getParentHandle(), getName(), &m_objectHandle);

    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - A429RawWord::initialiseWord VIP429_GetWord: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}