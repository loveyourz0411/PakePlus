

#pragma once
#include "NonProtocolParameterBase.h"
#include "VIPSimUserProtocol.h"
#include "VIPSimKernal.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class NonProtocolParameter : public NonProtocolParameterBase
{
public:

    NonProtocolParameter(VIP_CollectionHandle aCollectionHandle, std::string aName)
        : NonProtocolParameterBase(aCollectionHandle, aName)
    {
    }

    T getValue();
 
    VIP_Result setValue(T aValue);
};
