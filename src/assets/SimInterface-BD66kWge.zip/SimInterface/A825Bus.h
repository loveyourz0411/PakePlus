﻿#pragma once
#include "SimCoreShell.h"
#include "A825Message.h"
#include "A825APeriodic.h"
#include "A825Periodic.h"
#include "VIPBaseTypes.h"
#include "VIPSimA825.h"
#include "VIPSimKernal.h"
#include <iostream>
#include <vector>
using namespace std;

class A825Bus: public SimCoreShell<VIP825_BusHandle, VIP_ParticipantHandle>
{

    private:
        std::vector<A825Periodic*>* m_periodicMsgs;
        std::vector<A825APeriodic*>* m_aPeriodicMsgs;

    protected:
        VIP_Direction m_busDirection;
        VIP_Int32 m_queueLength;
        VIP_QueueLossType m_queueLossType;

        virtual VIP_Result setupMessage() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addPeriodicmsg
        //
        /// <summary>
        /// Add periodic msg to internal list
        /// </summary>
        void addPeriodicMsg(A825Periodic* msgObject);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addAPeriodicmsg
        //
        /// <summary>
        /// Add APeriodic msg to internal list
        /// </summary>
        void addAPeriodicMsg(A825APeriodic* msgObject);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startStopPeriodic
        //
        /// <summary>
        /// Start or Stop periodic msgs.
        /// </summary>
        VIP_Result startStopPeriodic(VIP_Bool start);
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
    public:
        A825Bus(VIP_ParticipantHandle aParticipantHandle, 
                std::string aPortName, 
                VIP_Direction aDirection, 
                VIP_Int32 aQueueLength = 0,
                VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        /// <summary>
        /// Class Destructor
        /// </summary>
        ~A825Bus();


        VIP_Result initialise();
        
        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the latest data for the Bus.  Can be called multiple times and will return
        /// VIP_NO_DATA if there is no more data
        /// </summary>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send the buses associated words 
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodicWords
        //
        /// <summary>
        /// Stop sending or receiving the periodic Words assigned to this bus
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodicWords
        //
        /// <summary>
        /// Start sending or receiving the periodic Words assigned to this bus
        /// </summary>
        VIP_Result startPeriodic();
};