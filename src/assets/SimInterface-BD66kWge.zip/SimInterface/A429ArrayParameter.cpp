

#include "A429ArrayParameter.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// getArray template function Specialisation
//
/// <summary>
/// getArray template function Specialisation for VIP_Char Array parameter
/// </summary>
template<>
VIP_Result A429ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    getArray( VIP_UInt32 aMaxLength, VIP_Char* aData, VIP_UInt32* aDataLength )
{
    return VIP429_GetValueString( getHandle(), aMaxLength, aData, aDataLength );
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setArray template function Specialisation
//
/// <summary>
/// setArray template function Specialisation for VIP_Char Array parameter
/// </summary>
template<>
VIP_Result A429ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    setArray( const VIP_Char* aData, VIP_UInt32 aDataLength )
{
    return VIP429_SetValueString( getHandle(), aData, aDataLength );
}