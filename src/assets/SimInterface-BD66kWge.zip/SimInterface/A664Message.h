

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA664Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>

class A664Message : public SimCoreShell<VIP664_MessageHandle, VIP_ParticipantHandle>
{
protected:
    VIP_Int32 m_sizeInBytes;
    VIP_Direction m_direction;
    VIP_QueueType m_queueType;
    VIP_Int32 m_queueLength;
    VIP_QueueLossType m_queueLossType;

    ///////////////////////////////////////////////////////////////////////////////////////////
    // setupParameters
    //
    /// <summary>
    /// To be implemented by code generated class to add the parameters to this object
    /// </summary>
    virtual VIP_Result setupData() = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////
    // initialise
    //
    /// <summary>
    /// Initialise method to setup the message 
    /// </summary>
    VIP_Result initialise();

    ///////////////////////////////////////////////////////////////////////////////////////////
    // setDirection
    //
    /// <summary>
    /// Setup the collection as a publisher or subscriber
    /// </summary>
    VIP_Result setDirection();

public:

    ///////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Parameters: aParticipantHandle 
    ///             aName,
    ///             aSizeInBytes,
    ///             aDirection, 
    ///             aQueueType (Optional - this is only used by the subscribing Messages)
    ///             aQueueLength (Optional - this is only used by the subscribing Messages)
    ///             aQueueLossType (Optional - this is only used by the subscribing Messages)
    /// </summary>
    A664Message(VIP_ParticipantHandle aParticpantHandle,
                std::string aName,
                VIP_Int32 aSizeInBytes,
                VIP_Direction aDirection,
                VIP_QueueType aQueueType = VIP_QueueType_Snapshot,
                VIP_Int32 aQueueLength = 0,
                VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

    ///////////////////////////////////////////////////////////////////////////////////////////
    // Destructor
    //
    virtual ~A664Message();

    ///////////////////////////////////////////////////////////////////////////////////////////
    // GetMessageVLID
    //
    /// <summary>
    /// Returns the Virtual Link ID associated with this message
    /// </summary>
    VIP_UInt16 getMessageVLID();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getData
    //
    /// <summary>
    /// Obtains a message payload as raw data. The complete message payload is returned, from 
    /// the first FS field, to the last DataParameter, as a byte array with length given by
    /// aMaxLength.
    /// Parameters: aMaxLength - Maximum data length that may be returned.
    ///             aRawData - Pointer to an array that will receive the data.
    ///             aDataLength - Pointer to a variable that will receive actual data length.
    /// </summary>
    VIP_Result getData(VIP_UInt32 aMaxLength, VIP_UInt8* aRawData, VIP_UInt32* aDataLength);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setData
    //
    /// <summary>
    /// Sets a message payload as raw data. The complete message is set from a byte array 
    /// with length given by aDataLength.
    /// Parameters: aRawData - Pointer to an array holding the data.
    ///             aDataLength - Data length to be set.
    /// </summary>
    VIP_Result setData(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // sizeInBytes
    //
    /// <summary>
    /// Get the size of the message payload in bytes.
    /// </summary>
    VIP_Int32 sizeInBytes();
};
