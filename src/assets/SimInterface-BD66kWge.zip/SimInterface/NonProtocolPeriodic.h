
#pragma once

#include "NonProtocolMessage.h"
#include "VIPSimUserProtocol.h"
#include <iostream>
#include <vector>

class NonProtocolPeriodic
{
    protected:
        VIP_Handle m_CollectionHandle;
        VIP_UInt8 m_ReceivedFlag;
        VIP_Direction m_Direction;


        /// Initialise Periodic Class with a valid VIP_CollectionHandle and the VIP_Direction
        VIP_Result initialisePeriodic(VIP_CollectionHandle CollectionHandle,
                                      VIP_Direction aDirection);

    public:

        NonProtocolPeriodic();
        /// Stop sending periodic word
        VIP_Result stopPeriodic();

        /// start sending periodic word 
        VIP_Result startPeriodic();

        /// Gets the value of the Collection Receive Flag 
        VIP_UInt8 getReceivedFlag();

        /// Sets the value of the Collection Receive Flag 
        void setReceivedFlag(VIP_UInt8 aValue);
};