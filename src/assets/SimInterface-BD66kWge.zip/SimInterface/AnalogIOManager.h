

#pragma once
#include "AnalogMessage.h"
#include "AnalogAPeriodic.h"
#include "AnalogPeriodic.h"
#include "VIPBaseTypes.h"
#include <iostream>
#include <vector>

class AnalogIOManager
{
    private:
        std::vector<AnalogPeriodic*>* m_PeriodicMessages;
        std::vector<AnalogAPeriodic*>* m_APeriodicMessages;

    protected:
        VIP_ParticipantHandle m_ParticipantHandle;
                    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // addPeriodicMessage
        //
        /// <summary>
        /// Add periodic message to internal list
        /// </summary>
        void addPeriodicMessage(AnalogPeriodic* aMessage);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addAPeriodicMessage
        //
        /// <summary>
        /// Add APeriodic message to internal list
        /// </summary>
        void addAPeriodicMessage(AnalogAPeriodic* aMessage);
        
    public:
        AnalogIOManager(VIP_ParticipantHandle aParticipantHandle);
        ~AnalogIOManager();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupIO
        //
        /// <summary>
        /// setupMessages virtual function used to setup the messages
        /// </summary>
        virtual VIP_Result setupMessages() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Receive
        //
        /// <summary>
        /// Receives all the Analog messages
        /// If an error is returned by one of the messages the method returns immediatley with the
        /// VIP result error.
        /// Therefore it will not attempt to receive the rest of the Analogs messages in the list.
        /// If all the Analogs were received without error (even if no new data was received) the
        /// method returns VIP_Success.
        /// </summary>
        /// <returns>A VIP_Result value</returns>
        /// <list> 
        /// <item>VIP_Success - All Analogs were received The operation completed successfully.</item>
        /// <item>VIP_BadHandle - A Analogs handle was invalid.</item>
        /// <item>VIP_InvalidOperation - The Analogs is not published, or is periodic</item>
        /// </list>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send Messages
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startAllPeriodics
        //
        /// <summary>
        /// Starts all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result startAllPeriodics();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopAllPeriodics
        //
        /// <summary>
        /// Stops all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result stopAllPeriodics();
};
