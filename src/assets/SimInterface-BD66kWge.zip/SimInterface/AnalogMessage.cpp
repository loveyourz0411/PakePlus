

#include "AnalogMessage.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
AnalogMessage::AnalogMessage(VIP_ParticipantHandle aParticpantHandle, 
                             std::string aName, 
                             VIP_Direction aDirection,
                             VIP_QueueType aQueueType,
                             VIP_Int32 aQueueLength,
                             VIP_QueueLossType aQueueLossType)
                             : SimCoreShell(aParticpantHandle, aName)
{
    m_Direction = aDirection;
    m_QueueType = aQueueType;
    m_QueueLength = aQueueLength;
    m_QueueLossType = aQueueLossType;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
AnalogMessage::~AnalogMessage()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result AnalogMessage::initialise()
{
    VIP_Result lResult;
    
    // Get the collection from the port name 
    lResult = VIPAnalog_GetFromPort(getParentHandle(), getName(), &m_objectHandle);

    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - Get Analog Message from PortName Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setDirection 
//
VIP_Result AnalogMessage::setDirection()
{
    VIP_Result lResult;

    if (m_Direction == VIP_Direction_Publish)
    {
        // Publish the message  
        lResult = VIPAnalog_Publish(getHandle());

        if (lResult != VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Publishing Analog Message Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else if (m_Direction == VIP_Direction_Subscribe)
    {
        lResult = VIPAnalog_SetQueueLength(getHandle(), m_QueueLength, m_QueueLossType);

        if (lResult == VIP_Success)
        {
            // Subscribe to Message            
            lResult = VIPAnalog_Subscribe(getHandle(), m_QueueType);

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Subscribe to Analog Message: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - VIPAnalog_SetQueueLength: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetValue
//
VIP_Double AnalogMessage::getValue()
{
    VIP_Double lValue = 0;

    VIPAnalog_GetValue(getHandle(), &lValue);


    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetValue
//
VIP_Result AnalogMessage::setValue(VIP_Double aValue)
{
  return VIPAnalog_SetValue(getHandle(), aValue);
}
