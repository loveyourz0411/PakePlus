
#include "AnalogPeriodic.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
AnalogPeriodic::AnalogPeriodic()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialisePeriodic
//
VIP_Result AnalogPeriodic::initialisePeriodic(VIPAnalog_MessageHandle aAnalogHandle)
{
    VIP_Result lResult;
    m_AnalogHandle = aAnalogHandle;

    // Link the received flag 
    lResult = VIPAnalog_LinkMessageReceivedFlag(m_AnalogHandle, &m_ReceivedFlag);

    return lResult;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodic
//
/// <summary>
/// Stop sending periodic word
/// </summary>
VIP_Result AnalogPeriodic::stopPeriodic()
{
    return VIPAnalog_StopPeriodic(m_AnalogHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
/// <summary>
/// start sending periodic word 
/// </summary>
VIP_Result AnalogPeriodic::startPeriodic()
{
    return VIPAnalog_StartPeriodic(m_AnalogHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetReceivedFlag
//
VIP_UInt8 AnalogPeriodic::getReceivedFlag()
{
    return m_ReceivedFlag;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetReceivedFlag (Used to reset the received flag VIP does not reset the flag that is the users
// responsibility)
//
void AnalogPeriodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_ReceivedFlag = aValue;
}