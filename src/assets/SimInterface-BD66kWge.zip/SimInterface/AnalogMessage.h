

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimAnalog.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>

class AnalogMessage : public SimCoreShell<VIPAnalog_MessageHandle, VIP_ParticipantHandle>
{
    protected:
        VIP_Direction m_Direction;
        VIP_QueueType m_QueueType;
        VIP_Int32 m_QueueLength;
        VIP_QueueLossType m_QueueLossType;

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise method to setup the message 
        /// </summary>
        VIP_Result initialise();

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // setDirection
        //
        /// <summary>
        /// Setup the collection as a publisher or subscriber
        /// </summary>
        VIP_Result setDirection();

    public:
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Parameters: ParticipantHandle 
        ///             Name, 
        ///             Direction
        ///             Queue Type
        ///             Queue Length
        ///             Queue Loss Type
        /// </summary>
        AnalogMessage(VIP_ParticipantHandle aParticpantHandle, 
                      std::string aName, 
                      VIP_Direction aDirection,
                      VIP_QueueType aQueueType = VIP_QueueType_Snapshot,
                      VIP_Int32 aQueueLength = 1,
                      VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // DeConstructor
        //
        ~AnalogMessage();

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // GetValue
        //
        /// <summary>
        /// Returns the value of this message
        /// </summary>
        VIP_Double getValue();

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // SetValue
        //
        /// <summary>
        /// Sets the value of this message
        /// </summary>
        VIP_Result setValue( VIP_Double aValue );
};
