

#include "A664Parameter.h"
#include "VIPSimA664.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Char A664Parameter<VIP_Bool, VIP_Type_Bool>::getValue()
{
    VIP_Char lValue = 0;

    VIP664_GetValueBool(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_Bool, VIP_Type_Bool>::setValue(VIP_Char aValue)
{
    return VIP664_SetValueBool(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Int32 A664Parameter<VIP_Int32, VIP_Type_Int32>::getValue()
{
    VIP_Int32 lValue = 0;

    VIP664_GetValueInt32(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_Int32, VIP_Type_Int32>::setValue(VIP_Int32 aValue)
{
    return VIP664_SetValueInt32(getHandle(), aValue);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int64 parameter
/// </summary>
template<>
VIP_Int64 A664Parameter<VIP_Int64, VIP_Type_Int64>::getValue()
{
    VIP_Int64 lValue = 0;

    VIP664_GetValueInt64(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int64 parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_Int64, VIP_Type_Int64>::setValue(VIP_Int64 aValue)
{
    return VIP664_SetValueInt64(getHandle(), aValue);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_UInt32 parameter
/// </summary>
template<>
VIP_UInt32 A664Parameter<VIP_UInt32, VIP_Type_UInt32>::getValue()
{
    VIP_UInt32 lValue = 0;

    VIP664_GetValueUInt32(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_UInt32 parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_UInt32, VIP_Type_UInt32>::setValue(VIP_UInt32 aValue)
{
    return VIP664_SetValueUInt32(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_UInt64 parameter
/// </summary>
template<>
VIP_UInt64 A664Parameter<VIP_UInt64, VIP_Type_UInt64>::getValue()
{
    VIP_UInt64 lValue = 0;

    VIP664_GetValueUInt64(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_UInt64 parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_UInt64, VIP_Type_UInt64>::setValue(VIP_UInt64 aValue)
{
    return VIP664_SetValueUInt64(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Float A664Parameter<VIP_Float, VIP_Type_Float>::getValue()
{
    VIP_Float lValue = 0;

    VIP664_GetValueFloat(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_Float, VIP_Type_Float>::setValue(VIP_Float aValue)
{
    return VIP664_SetValueFloat(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Double A664Parameter<VIP_Double, VIP_Type_Double>::getValue()
{
    VIP_Double lValue = 0;

    VIP664_GetValueDouble(getHandle(), &lValue);

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Result A664Parameter<VIP_Double, VIP_Type_Double>::setValue(VIP_Double aValue)
{
    return VIP664_SetValueDouble(getHandle(), aValue);
}
