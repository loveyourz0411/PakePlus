

#pragma once
#include "VIPSimA429.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>

class A429ParameterBase : public SimCoreShell<VIP429_ParameterHandle, VIP429_WordHandle>
{
    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="aWordHandle">Word Handle</param>
        /// <param name="aParameterName">Parameter Name</param>
        /// <param name="aParamType">Parameter Type</param>
        A429ParameterBase(VIP429_WordHandle aWordHandle, std::string aParameterName,
                          VIP429_ParameterType aParamType);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        /// <summary>
        /// Destructor
        /// </summary>
        ~A429ParameterBase();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise parameter with the VIP
        /// </summary>
        VIP_Result initialise();

    protected:
        VIP429_ParameterType m_ParameterType;
};