#include "A429IOManager.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429IOManager::A429IOManager(VIP_ParticipantHandle aParticipantHandle)
{
    m_ParticipantHandle = aParticipantHandle;

    m_buses = new std::vector<A429Bus*>();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429IOManager::~A429IOManager()
{
    if (m_buses != NULL)
    {
        delete m_buses;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Add and initialise bus
//
void A429IOManager::addBus(A429Bus* aBusObject)
{     
    if (m_buses != NULL)
    {
        m_buses->push_back(aBusObject);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Receive Buses
//
VIP_Result A429IOManager::receive()
{
    // Receive aPeriodic Messages 
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( (lResult == VIP_Success || lResult == VIP_NoData) && i < m_buses->size() )
    {   
        // Step through all buses and call their receive methods
        lResult = (*m_buses)[i]->receive();
        i++;
    }

    // Return VIP_Success if the last receive call returned VIP_NoData 
    // as this is still a successful receive.
    // if the while loop quit due to an error then just return it.
    if (lResult == VIP_NoData)
        lResult = VIP_Success;

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Send Buses
//
VIP_Result A429IOManager::send()
{
    // Send aPeriodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_buses->size() )
    {        
        // Call the Send function of the Message 
        lResult = (*m_buses)[i]->send();     
        i++;
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Start All Periodics 
//
VIP_Result A429IOManager::startAllPeriodics()
{
    // Start Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_buses->size() )
    {        
        // Call the startPeriodic function of the Message 
        lResult = (*m_buses)[i]->startPeriodic();    
        i++;
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Stop All Periodics
//
VIP_Result A429IOManager::stopAllPeriodics()
{
    // Stop Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_buses->size() )
    {        
        // Call the stopPeriodic function of the Message 
        lResult = (*m_buses)[i]->stopPeriodic();    
        i++;
    }

    return lResult;
}