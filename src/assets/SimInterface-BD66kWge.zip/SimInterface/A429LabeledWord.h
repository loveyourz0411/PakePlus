

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA429.h"
#include "VIPSimKernal.h"
#include "A429WordBase.h"
#include <iostream>
#include <vector>

class A429LabeledWord : public A429WordBase
{
    private:
        VIP_UInt32 m_Label;

    protected:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupParameters
        //
        /// <summary>
        /// To be implemented by code generated class to initialise the object by 
        //  add the parameters to this word
        /// </summary>
        virtual VIP_Result setupParameters() = 0;

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        /// <param name="aVIPDirection">Bus Handle</param>
        /// <param name="aWordName">Word Name</param>
        /// <param name="aLabel">Label</param>
        A429LabeledWord(VIP429_BusHandle aBusHandle, std::string aWordName, VIP_UInt32 aLabel);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429LabeledWord();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the word with the VIP
        /// </summary>
        VIP_Result initialiseWord();
};
