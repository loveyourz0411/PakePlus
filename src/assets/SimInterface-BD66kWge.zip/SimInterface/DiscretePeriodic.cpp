
#include "DiscretePeriodic.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
DiscretePeriodic::DiscretePeriodic()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// initialisePeriodic
//
VIP_Result DiscretePeriodic::initialisePeriodic(VIPDiscrete_MessageHandle aDiscreteHandle)
{
    VIP_Result lResult;
    m_DiscreteHandle = aDiscreteHandle;

    // Link the received flag 
    lResult = VIPDiscrete_LinkMessageReceivedFlag(m_DiscreteHandle, &m_ReceivedFlag);

    return lResult;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodic
//
/// <summary>
/// Stop sending periodic word
/// </summary>
VIP_Result DiscretePeriodic::stopPeriodic()
{
    return VIPDiscrete_StopPeriodic(m_DiscreteHandle);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
/// <summary>
/// start sending periodic word 
/// </summary>
VIP_Result DiscretePeriodic::startPeriodic()
{
    return VIPDiscrete_StartPeriodic(m_DiscreteHandle);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// GetReceivedFlag
//
VIP_UInt8 DiscretePeriodic::getReceivedFlag()
{
    return m_ReceivedFlag;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// SetReceivedFlag (Used to reset the received flag VIP does not reset the flag that is the users
// responsibility)
//
void DiscretePeriodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_ReceivedFlag = aValue;
}
