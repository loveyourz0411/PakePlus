#pragma once
#include "A825Message.h"
#include "VIPSimA825Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>

class A825ParameterBase : public SimCoreShell<VIP825_ParameterHandle, VIP825_MessageHandle>
{
    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Constructor
        /// </summary>
        A825ParameterBase(VIP825_MessageHandle aMessageHandle, std::string aName);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        /// <summary>
        /// Destructor
        /// </summary>
        virtual ~A825ParameterBase();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise parameter with the VIP
        /// </summary>
        VIP_Result initialise();
};
