#include "A825ArrayParameter.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// getArray
//
/// <summary>
/// Get Array from the VIP (Specialisation for Opaque array)
/// </summary>
// template<>
// VIP_Result A825ArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
//     getArray(VIP_UInt32 aMaxLength, VIP_UInt8* aData, VIP_UInt32* aDataLength)
// {
//     return VIP825_GetValueOpaque(getHandle(), aMaxLength, aData, aDataLength);
// }

// ///////////////////////////////////////////////////////////////////////////////////////////////////
// // setArray
// //
// /// <summary>
// /// Set VIP Array (Specialisation for Opaque Array)
// /// </summary>
// template<>
// VIP_Result A825ArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
//     setArray(VIP_UInt8* aData, VIP_UInt32 aDataLength)
// {
//     return VIP825_SetValueOpaque(getHandle(), aData, aDataLength);
// }

///////////////////////////////////////////////////////////////////////////////////////////////////
// getArray
//
/// <summary>
/// Get Array from the VIP (Specialisation for ASCII array)
/// </summary>
template<>
VIP_Result A825ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Char* aData, VIP_UInt32* aDataLength)
{
    return VIP825_GetValueString(getHandle(), aMaxLength, aData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setArray
//
/// <summary>
/// Set VIP Array (Specialisation for ASCII Array)
/// </summary>
template<>
VIP_Result A825ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    setArray(VIP_Char* aData, VIP_UInt32 aDataLength)
{
    return VIP825_SetValueString(getHandle(), aData, aDataLength);
}
