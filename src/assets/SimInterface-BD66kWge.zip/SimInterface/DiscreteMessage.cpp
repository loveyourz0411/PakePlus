

#include "DiscreteMessage.h"
#ifndef __linux__
#include <windows.h>
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
DiscreteMessage::DiscreteMessage( VIP_ParticipantHandle aParticpantHandle, 
                                  std::string aName, VIP_Direction aDirection,
                                  VIP_QueueType aQueueType,
                                  VIP_Int32 aQueueLength,
                                  VIP_QueueLossType aQueueLossType)
                                  : SimCoreShell(aParticpantHandle, aName)
{
    m_Direction = aDirection;
    m_QueueType = aQueueType;
    m_QueueLength = aQueueLength;
    m_QueueLossType = aQueueLossType;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
DiscreteMessage::~DiscreteMessage()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result DiscreteMessage::initialise()
{
    VIP_Result lResult;
    
    // Get the collection from the port name 
    lResult = VIPDiscrete_GetFromPort(getParentHandle(), getName(), &m_objectHandle);
    printf("Name:%s\n", getName());
    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - Get Discrete Message from PortName Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";

        printf("Result %d ,%s\n", lResult,lMessage);
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// SetDirection 
//
VIP_Result DiscreteMessage::setDirection()
{
    VIP_Result lResult;

    if (m_Direction == VIP_Direction_Publish)
    {
        // Publish the message  
        lResult = VIPDiscrete_Publish(getHandle());

        if (lResult != VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Publishing Discrete Message Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else if (m_Direction == VIP_Direction_Subscribe)
    {
        // Set Queue parameters
        lResult = VIPDiscrete_SetQueueLength(getHandle(), m_QueueLength, m_QueueLossType);

        if (lResult == VIP_Success)
        {
            // Subscribe to Message
            lResult = VIPDiscrete_Subscribe(getHandle(), m_QueueType);

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Subscribe to Discrete Message: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - VIPDiscrete_SetQueueLength: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getValue
//
VIP_Bool DiscreteMessage::getValue()
{
    VIP_Bool lValue = false;

    VIPDiscrete_GetValue(getHandle(), &lValue);

    return lValue;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setValue
//
VIP_Result DiscreteMessage::setValue(VIP_Bool aValue)
{
    return VIPDiscrete_SetValue(getHandle(), aValue);
}
