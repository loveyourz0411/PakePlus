#include "A825APeriodic.h"
#include "VIPSimA825.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
/// <summary>
/// Class Constructor
/// </summary>
A825APeriodic::A825APeriodic()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialiseAPeriodic
//
void A825APeriodic::initialiseAPeriodic(VIP825_BusHandle aBusHandle, VIP825_MessageHandle aMessageHandle)
{
    m_busHandle = aBusHandle;
    m_messageHandle = aMessageHandle;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// send
//
VIP_Result A825APeriodic::send()
{
    //return VIP_Success;
    VIP_Result lResult = VIP_InvalidOperation;
    if(m_messageHandle != NULL)
    {
        lResult = addToBusSendBuffer();
        if(lResult == VIP_Success)
        {
            lResult = VIP825_SendBuffer(m_busHandle);
        }
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// receive
//
VIP_Result A825APeriodic::receive()
{
    return VIP825_Receive(m_busHandle);
}



void A825APeriodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_receivedFlag = aValue;
}

VIP_UInt8 A825APeriodic::getReceivedFlag()
{
    return m_receivedFlag;
}

VIP_Result A825APeriodic::addToBusSendBuffer()
{
    VIP_Result lResult = VIP_InvalidOperation;
    if(m_messageHandle != NULL)
    {
        lResult = VIP825_AddToBuffer(m_messageHandle);
    }
    return lResult;
}