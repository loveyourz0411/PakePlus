

#include "AnalogIOManager.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
AnalogIOManager::AnalogIOManager(VIP_ParticipantHandle aParticipantHandle)
{
    m_ParticipantHandle = aParticipantHandle;
    
    // Create new lists for Periodic and APeriodic Messages
    m_APeriodicMessages = new std::vector<AnalogAPeriodic*>();
    m_PeriodicMessages = new std::vector<AnalogPeriodic*>();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
AnalogIOManager::~AnalogIOManager()
{
    // Clean up 
    if (m_APeriodicMessages != NULL)
    {
        delete m_APeriodicMessages;
    }

    if (m_PeriodicMessages != NULL)
    {
        delete m_PeriodicMessages;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addPeriodicMessage
//
/// <summary>
/// Add periodic message to internal list
/// </summary>
void AnalogIOManager::addPeriodicMessage(AnalogPeriodic* aMessage)
{
    if (m_PeriodicMessages != NULL)
    {
        m_PeriodicMessages->push_back(aMessage);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addAPeriodicMessage
//
/// <summary>
/// Add APeriodic message to internal list
/// </summary>
void AnalogIOManager::addAPeriodicMessage(AnalogAPeriodic* aMessage)
{
    if (m_APeriodicMessages != NULL)
    {
        m_APeriodicMessages->push_back(aMessage);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Receive
//
/// <summary>
/// Receive APeriodic Analog Messages
/// </summary>
VIP_Result AnalogIOManager::receive()
{
    // Receive aPeriodic Messages 
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( (lResult == VIP_Success || lResult == VIP_NoData) && i < m_APeriodicMessages->size() )
    {    
        lResult = (*m_APeriodicMessages)[i]->receive();
        i++;
    }

    // Return VIP_Success if the last receive call returned VIP_NoData 
    // as this is still a successful receive.
    // if the while loop quit due to an error then just return it.
    if (lResult == VIP_NoData)
        lResult = VIP_Success;

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Send
//
/// <summary>
/// Send Analog Messages
/// </summary>
VIP_Result AnalogIOManager::send()
{
    // Send aPeriodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_APeriodicMessages->size() )
    {        
        // Call the Send function of the Message 
        lResult = (*m_APeriodicMessages)[i]->send();
        i++;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Start All Periodics 
//
VIP_Result AnalogIOManager::startAllPeriodics()
{    
    // Start Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the startPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->startPeriodic();
        i++;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Stop All Periodics
//
VIP_Result AnalogIOManager::stopAllPeriodics()
{
    // Stop Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the stopPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->stopPeriodic();
        i++;
    }

    return lResult;
}