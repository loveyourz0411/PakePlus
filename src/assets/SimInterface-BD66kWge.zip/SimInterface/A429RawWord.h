

#pragma once
#include "A429WordBase.h"
#include "VIPBaseTypes.h"
#include "VIPSimA429.h"
#include "VIPSimKernal.h"
#include <iostream>
#include <vector>

class A429RawWord : public A429WordBase
{
    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        /// <param name="aVIPDirection">Bus Handle</param>
        /// <param name="aWordName">Word Name</param>
        A429RawWord(VIP429_BusHandle aBusHandle, std::string aWordName);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429RawWord();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the word with the VIP
        /// </summary>
        VIP_Result initialiseWord();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setLabel
        //
        /// <summary>
        /// Sets the Label value
        /// </summary>
        void setLabel(VIP_UInt32 aValue);
};
