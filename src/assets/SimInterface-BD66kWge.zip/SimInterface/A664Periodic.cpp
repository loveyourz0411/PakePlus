
#include "A664Periodic.h"
#include "VIPSimA664.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A664Periodic::A664Periodic()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// initialisePeriodic
//
VIP_Result A664Periodic::initialisePeriodic(VIP664_MessageHandle aMessageHandle)
{
    VIP_Result lResult;

    m_MessageHandle = aMessageHandle;

    // Link the received flag 
    lResult = VIP664_LinkMessageReceivedFlag(m_MessageHandle, &m_ReceivedFlag);

    return lResult;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodic
//
/// <summary>
/// Stop sending periodic word
/// </summary>
VIP_Result A664Periodic::stopPeriodic()
{
    return VIP664_StopPeriodic(m_MessageHandle);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
/// <summary>
/// start sending periodic word 
/// </summary>
VIP_Result A664Periodic::startPeriodic()
{
    return VIP664_StartPeriodic(m_MessageHandle);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// GetReceivedFlag
//
VIP_UInt8 A664Periodic::getReceivedFlag()
{
    return m_ReceivedFlag;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setReceivedFlag (Used to reset the received flag VIP does not reset the flag that is the users
// responsibility)
//
void A664Periodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_ReceivedFlag = aValue;
}