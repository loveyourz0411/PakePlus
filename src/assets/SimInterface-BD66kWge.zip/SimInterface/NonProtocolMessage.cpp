

#include "NonProtocolMessage.h"


NonProtocolMessage::NonProtocolMessage(VIP_ParticipantHandle aParticpantHandle, 
                                       std::string aName, 
                                       VIP_Direction aDirection, 
                                       VIP_QueueType aQueueType,
                                       VIP_Int32 aQueueLength,
                                       VIP_QueueLossType aQueueLossType)
                                       : SimCoreShell(aParticpantHandle, aName)
{
    m_Direction = aDirection;
    m_QueueType = aQueueType;
    m_QueueLength = aQueueLength;
    m_QueueLossType = aQueueLossType;
}


NonProtocolMessage::~NonProtocolMessage()
{
}


VIP_Result NonProtocolMessage::initialise()
{
    VIP_Result lResult;
    
    // Get the collection from the port name 
    //lResult = VIP_GetCollectionFromPort(etParentHandle(), getName(), &m_objectHandle);
    lResult = VIPUserProtocol_GetMessage(getParentHandle(), getName(), &m_objectHandle);//ToDo：pararentHanle is portHandle or participantHandle??

    if (lResult == VIP_Success)
    {
        // Setup the parameters of this message 
        lResult = setupParameters();
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR - Get NPD Message (collection) from PortName Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}


VIP_Result NonProtocolMessage::setDirection()
{
    VIP_Result lResult;

    if (m_Direction == VIP_Direction_Publish)
    {
        // Set Collection Direction (Publish or Subscribe)
        //lResult = VIP_PublishCollection(getHandle());
        lResult = VIPUserProtocol_Publish(getHandle());

        if (lResult != VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Publish Message Collection Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else if (m_Direction == VIP_Direction_Subscribe)
    {
        // Set Queue parameters
        lResult = VIPNPD_SetQueueLength(getHandle(), m_QueueLength, m_QueueLossType);

        if (lResult == VIP_Success)
        {
            // Set Bus Direction (Publish or Subscribe)
            //lResult = VIP_SubscribeToCollection(getHandle(), m_QueueType);
            lResult = VIPUserProtocol_Subscribe(getHandle());

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Subscribe Message Collection Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
               // lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - VIP_SetCollectionQueueLength: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }

    return lResult;
}
