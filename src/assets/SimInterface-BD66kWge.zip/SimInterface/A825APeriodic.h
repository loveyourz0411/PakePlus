#pragma once
//#include "A825Bus.h"
#include "VIPBaseTypes.h"
#include "VIPSimA825.h"
#include <iostream>
#include <vector>

class A825APeriodic
{
    protected:
        VIP825_BusHandle m_busHandle;
        VIP825_MessageHandle m_messageHandle;
        VIP_UInt8 m_receivedFlag;
        

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
        A825APeriodic();
       
        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Sends the message/collection 
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the message/collection 
        /// </summary>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialiseAPeriodic
        //
        // Initialise the class with a valid VIP_CollectionHandle
        /// <summary>
        /// Initialise the class.
        /// </summary>
        void initialiseAPeriodic(VIP825_BusHandle aBusHandle, VIP825_MessageHandle aMessageHandle);

        void setReceivedFlag(VIP_UInt8 aValue);

        VIP_UInt8 getReceivedFlag();

        VIP_Result addToBusSendBuffer();
};