

#include "NonProtocolIOManager.h"


NonProtocolDataIOManager::NonProtocolDataIOManager(VIP_ParticipantHandle aParticipantHandle)
{
    m_ParticipantHandle = aParticipantHandle;
    
    // Create new lists for Periodic and APeriodic Messages
    m_APeriodicMessages = new std::vector<NonProtocolAPeriodic*>();
    m_PeriodicMessages = new std::vector<NonProtocolPeriodic*>();
}


NonProtocolDataIOManager::~NonProtocolDataIOManager()
{
    // Clean up 
    if (m_APeriodicMessages != NULL)
    {
        delete m_APeriodicMessages;
    }

    if (m_PeriodicMessages != NULL)
    {
        delete m_PeriodicMessages;
    }
}


/// Add periodic message to internal list
void NonProtocolDataIOManager::addPeriodicMessage(NonProtocolPeriodic* aMessage)
{
    if (m_PeriodicMessages != NULL)
    {
        m_PeriodicMessages->push_back(aMessage);
    }
}


/// Add APeriodic message to internal list
void NonProtocolDataIOManager::addAPeriodicMessage(NonProtocolAPeriodic* aMessage)
{
    if (m_APeriodicMessages != NULL)
    {
        m_APeriodicMessages->push_back(aMessage);
    }
}


/// Receive APeriodic NPD Messages
VIP_Result NonProtocolDataIOManager::receive()
{
    // Receive aPeriodic Messages 
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( (lResult == VIP_Success || lResult == VIP_NoData) && i < m_APeriodicMessages->size() )
    {        
        // Call the Receive function of the Message 
        lResult = (*m_APeriodicMessages)[i]->receive();     
        i++;
    }

    // Return VIP_Success if the last receive call returned VIP_NoData 
    // as this is still a successful receive.
    // if the while loop quit due to an error then just return it.
    if (lResult == VIP_NoData)
        lResult = VIP_Success;

    return lResult;
}


/// Send NPD Messages
VIP_Result NonProtocolDataIOManager::send()
{
    // Send aPeriodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_APeriodicMessages->size() )
    {        
        // Call the Send function of the Message 
        lResult = (*m_APeriodicMessages)[i]->send();
        i++;
    }

    return lResult;
}


// Start All Periodics 
VIP_Result NonProtocolDataIOManager::startAllPeriodics()
{    
    // Start Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the startPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->startPeriodic();    
        i++;
    }

    return lResult;
}


// Stop All Periodics
VIP_Result NonProtocolDataIOManager::stopAllPeriodics()
{
    // Stop Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the stopPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->stopPeriodic();    
        i++;
    }

    return lResult;
}