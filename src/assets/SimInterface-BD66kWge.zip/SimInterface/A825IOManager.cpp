#include "A825IOManager.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A825DataIOManager::A825DataIOManager(VIP_ParticipantHandle aParticipantHandle)
{
    m_participantHandle = aParticipantHandle;

    // Create new lists for Periodic and APeriodic Messages
    m_buses = new std::vector<A825Bus*>();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A825DataIOManager::~A825DataIOManager()
{
    // Clean up 
    if(m_buses != NULL)
    {
        delete m_buses;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addPeriodicMessage
//
/// <summary>
/// Add periodic message to internal list
/// </summary>
void A825DataIOManager::addBus(A825Bus* aBusObject)
{
    if (m_buses != NULL)
    {
        m_buses->push_back(aBusObject);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// Receive
//
/// <summary>
/// Receive APeriodic NPD Messages
/// </summary>
VIP_Result A825DataIOManager::receive()
{
    // Receive aPeriodic Messages 
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ((lResult == VIP_Success || lResult == VIP_NoData) && i < m_buses->size())
    {        
        // Call the Receive function of the Message.
        lResult = (*m_buses)[i]->receive();
        i++;
    }

    // Return VIP_Success if the last receive call returned VIP_NoData  as this is still a
    // successful receive. if the while loop quit due to an error then just return it.
    if (lResult == VIP_NoData)
    {
        lResult = VIP_Success;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Send
//
/// <summary>
/// Send NPD Messages
/// </summary>
VIP_Result A825DataIOManager::send()
{
    // Send aPeriodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while (lResult == VIP_Success && i < m_buses->size())
    {        
        // Call the Send function of the Message 
        lResult = (*m_buses)[i]->send();
        i++;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Start All Periodics 
//
VIP_Result A825DataIOManager::startAllPeriodics()
{    
    // Start Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while (lResult == VIP_Success && i < m_buses->size())
    {        
        // Call the startPeriodic function of the Message 
        lResult = (*m_buses)[i]->startPeriodic();
        i++;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Stop All Periodics
//
VIP_Result A825DataIOManager::stopAllPeriodics()
{
    // Stop Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while (lResult == VIP_Success && i < m_buses->size())
    {        
        // Call the stopPeriodic function of the Message 
        lResult = (*m_buses)[i]->stopPeriodic();
        i++;
    }

    return lResult;
}
