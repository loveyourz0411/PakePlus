

#include "A664RawData.h"


///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor.
A664RawData::A664RawData(VIP664_MessageHandle aMessageHandle, VIP_Int32 aSizeInBytes)
{
    m_messageHandle = aMessageHandle;
    m_sizeInBytes = aSizeInBytes;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue
VIP_Result A664RawData::getValue(VIP_Int32 aMaxLength, VIP_UInt8* aRawData, VIP_Int32* aDataLength)
{
    return VIP664_GetRawMessage(m_messageHandle, aMaxLength, aRawData, (VIP_UInt32*)aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue
//
VIP_Result A664RawData::setValue(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength)
{
    return VIP664_SetRawMessage(m_messageHandle, aRawData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// sizeInBytes
//
VIP_Int32 A664RawData::sizeInBytes()
{
    return m_sizeInBytes;
}
