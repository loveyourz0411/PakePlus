

#pragma once
#include "NonProtocolParameterBase.h"
#include "VIPSimUserProtocol.h"
#include "VIPSimKernal.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class NonProtocolArrayParameter : public NonProtocolParameterBase
{
public:

    NonProtocolArrayParameter(VIP_CollectionHandle aCollectionHandle, std::string aName)
        : NonProtocolParameterBase(aCollectionHandle, aName)
    {
    }

    /// Get Array from the VIP (This method has specialisation for each VIP Type)
    VIP_Result getArray(VIP_UInt32 aMaxLength, T* aData, VIP_UInt32* aDataLength);


    /// Set the VIP Array (This method has specialisation for each VIP Type)
    VIP_Result setArray(T* aData, VIP_UInt32 aDataLength);
};
