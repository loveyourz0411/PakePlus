

#include "NonProtocolArrayParameter.h"


// Get Array from the VIP (Specialisation for VIP_Bool Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Bool, VIP_Type_BoolArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Bool* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueBoolArray(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueBoolArray(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Bool Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Bool, VIP_Type_BoolArray>::
    setArray(VIP_Bool* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueBoolArray(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueBoolArray(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Char Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Char, VIP_Type_CharArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Char* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueCharArray(getHandle(), aMaxLength, aData, aDataLength);
    return  VIPUserProtocol_GetValueString(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Char Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Char, VIP_Type_CharArray>::
    setArray(VIP_Char* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueCharArray(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueString(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Int8 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int8, VIP_Type_Int8Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_Int8* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueInt8Array(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueInt8Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Int8 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int8, VIP_Type_Int8Array>::
    setArray(VIP_Int8* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueInt8Array(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueInt8Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_UInt8 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_UInt8* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueUInt8Array(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueUInt8Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_UInt8 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
    setArray(VIP_UInt8* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueUInt8Array(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueUInt8Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Int16 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int16, VIP_Type_Int16Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_Int16* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueInt16Array(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueInt16Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Int16 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int16, VIP_Type_Int16Array>::
    setArray(VIP_Int16* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueInt16Array(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueInt16Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_UInt16 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt16, VIP_Type_UInt16Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_UInt16* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueUInt16Array(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueUInt16Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_UInt16 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt16, VIP_Type_UInt16Array>::
    setArray(VIP_UInt16* aData, VIP_UInt32 aDataLength)
{
    //return VIP_SetParameterValueUInt16Array(getHandle(), aData, aDataLength);
    return VIPUserProtocol_SetValueUInt16Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Int32 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int32, VIP_Type_Int32Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_Int32* aData, VIP_UInt32* aDataLength)
{
    //return VIP_GetParameterValueInt32Array(getHandle(), aMaxLength, aData, aDataLength);
    return VIPUserProtocol_GetValueInt32Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Int32 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int32, VIP_Type_Int32Array>::
    setArray(VIP_Int32* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueInt32Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_UInt32 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt32, VIP_Type_UInt32Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_UInt32* aData, VIP_UInt32* aDataLength)
{
    return VIPUserProtocol_GetValueUInt32Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_UInt32 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt32, VIP_Type_UInt32Array>::
    setArray(VIP_UInt32* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueUInt32Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Int64 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int64, VIP_Type_Int64Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_Int64* aData, VIP_UInt32* aDataLength)
{
    return VIPUserProtocol_GetValueInt64Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Int64 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Int64, VIP_Type_Int64Array>::
    setArray(VIP_Int64* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueInt64Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_UInt64 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt64, VIP_Type_UInt64Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_UInt64* aData, VIP_UInt32* aDataLength)
{
    return VIPUserProtocol_GetValueUInt64Array(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_UInt64 Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_UInt64, VIP_Type_UInt64Array>::
    setArray(VIP_UInt64* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueUInt64Array(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Float Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Float, VIP_Type_FloatArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Float* aData, VIP_UInt32* aDataLength)
{
    return VIPUserProtocol_GetValueFloatArray(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Float Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Float, VIP_Type_FloatArray>::
    setArray(VIP_Float* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueFloatArray(getHandle(), aData, aDataLength);
}


/// Get Array from the VIP (Specialisation for VIP_Double Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Double, VIP_Type_DoubleArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Double* aData, VIP_UInt32* aDataLength)
{
    return VIPUserProtocol_GetValueDoubleArray(getHandle(), aMaxLength, aData, aDataLength);
}


/// Set VIP Array (Specialisation for VIP_Double Array)
template<>
VIP_Result NonProtocolArrayParameter<VIP_Double, VIP_Type_DoubleArray>::
    setArray(VIP_Double* aData, VIP_UInt32 aDataLength)
{
    return VIPUserProtocol_SetValueDoubleArray(getHandle(), aData, aDataLength);
}
