
#include "A429ParameterBase.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429ParameterBase::A429ParameterBase(VIP429_WordHandle aWordHandle, std::string aParameterName,
                                     VIP429_ParameterType aParamType) :
                                     SimCoreShell(aWordHandle, aParameterName)
{
    m_ParameterType = aParamType;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429ParameterBase::~A429ParameterBase()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A429ParameterBase::initialise()
{
    VIP_Result lResult;
    // Create the parameter 
    lResult = VIP429_GetParameter(getParentHandle(), getName(), &m_objectHandle);

    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - A429ParameterBase::initialise  VIP429_GetParameter: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}


