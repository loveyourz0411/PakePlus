

#include "APeriodic.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
APeriodic::APeriodic()
{
    m_word = NULL;
    m_receivedFlag = 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialiseAPeriodic
//
VIP_Result APeriodic::initialiseAPeriodic(A429WordBase* aWord)
{
    m_word = dynamic_cast<A429WordBase*>(aWord);

    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        lResult = VIP429_LinkWordReceivedFlag(m_word->getHandle(), &m_receivedFlag);
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addToBusSendBuffer
//
VIP_Result APeriodic::addToBusSendBuffer()
{
    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        lResult = VIP429_AddToBuffer(m_word->getHandle());
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getReceivedFlag
//
VIP_UInt8 APeriodic::getReceivedFlag()
{
    return m_receivedFlag;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setReceivedFlag
//
void APeriodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_receivedFlag = aValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// send
//
VIP_Result APeriodic::send()
{
    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        lResult = addToBusSendBuffer();
        if (lResult == VIP_Success)
        {
            lResult = VIP429_SendBuffer(m_word->getParentHandle());
        }
    }
    return lResult;
}
