

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA664.h"
#include "VIPSimKernal.h"
#include "A664APeriodic.h"
#include "A664Periodic.h"
#include <iostream>
#include <vector>

class A664IOManager
{
private:
    std::vector<A664APeriodic*>* m_aPeriodicMessages;
    std::vector<A664Periodic*>* m_PeriodicMessages;

protected:
    VIP_ParticipantHandle m_ParticipantHandle;
    VIP_UInt16 m_VLID;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setupMessages
    //
    /// <summary>
    /// To be implemented by code generated class to add the messages to this object
    /// </summary>
    virtual VIP_Result setupMessages() = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // addPeriodicWord
    //
    /// <summary>
    /// Add periodic message to internal list
    /// </summary>
    void addPeriodicMessage(A664Periodic* aMessage);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // addAPeriodicWord
    //
    /// <summary>
    /// Add APeriodic message to internal list
    /// </summary>
    void addAPeriodicMessage(A664APeriodic* aMessage);

public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <param name="aVIPDirection">Participant Handle</param>
    A664IOManager(VIP_ParticipantHandle aParticipantHandle);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // DeConstructor
    //
    ~A664IOManager();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Receive
    //
    /// <summary>
    /// Receives all the messages
    /// If an error is returned by one of the messages the method returns immediately with the VIP
    /// result error.
    /// Therefore it will not attempt to receive the rest of the messages in the list.  If all the
    /// messages were received without error (even if no new data was received) the method returns
    /// VIP_Success
    /// </summary>
    /// <returns>A VIP_Result value</returns>
    /// <list> 
    /// <item>VIP_Success - All messages were received The operation completed successfully.</item>
    /// <item>VIP_BadHandle - A message handle was invalid.</item>
    /// <item>VIP_InvalidOperation - The message is not published, or is periodic</item>
    /// </list>
    VIP_Result receive();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // send
    //
    /// <summary>
    /// Send Messages
    /// </summary>
    VIP_Result send();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // startAllPeriodics
    //
    /// <summary>
    /// Starts all the periodic Messages (sending and receiving)
    /// </summary>
    VIP_Result startPeriodicMessages();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // stopAllPeriodics
    //
    /// <summary>
    /// Stops all the periodic Messages (sending and receiving)
    /// </summary>
    VIP_Result stopPeriodicMessages();
};