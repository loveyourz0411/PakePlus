

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include "VIPSimUserProtocol.h"
#include <iostream>
#include <vector>
#include <string>

class NonProtocolMessage : public SimCoreShell<VIP_CollectionHandle, VIP_ParticipantHandle>
{
    protected:
        VIP_Direction m_Direction;
        VIP_QueueType m_QueueType;
        VIP_Int32 m_QueueLength;
        VIP_QueueLossType m_QueueLossType;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupParameters
        //
        /// <summary>
        /// To be implemented by code generated class to add the parameters to this object
        /// </summary>
        virtual VIP_Result setupParameters() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise method to setup the message 
        /// </summary>
        VIP_Result initialise();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setDirection
        //
        /// <summary>
        /// Setup the collection as a publisher or subscriber
        /// </summary>
        VIP_Result setDirection();

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Parameters: ParticipantHandle 
        ///             Name, 
        ///             Direction, 
        ///             QueueType (Optional - this is only used by the subscribing Collections)
        /// </summary>
        NonProtocolMessage(VIP_ParticipantHandle aParticpantHandle, 
                           std::string aName, 
                           VIP_Direction aDirection, 
                           VIP_QueueType aQueueType = VIP_QueueType_Snapshot,
                           VIP_Int32 aQueueLength = 0,
                           VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~NonProtocolMessage();
};

