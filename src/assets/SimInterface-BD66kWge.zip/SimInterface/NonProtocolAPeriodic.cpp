

#include "NonProtocolAPeriodic.h"

NonProtocolAPeriodic::NonProtocolAPeriodic()
{
}


// initialiseAPeriodic
void NonProtocolAPeriodic::initialiseAPeriodic(VIP_CollectionHandle aCollectionHandle)
{
    m_CollectionHandle = aCollectionHandle;
}



VIP_Result NonProtocolAPeriodic::send()
{
    //return VIP_SendCollection(m_CollectionHandle);
    return VIPUserProtocol_Send(m_CollectionHandle);
}


VIP_Result NonProtocolAPeriodic::receive()
{
    //return VIP_ReceiveCollection(m_CollectionHandle);
    return VIPUserProtocol_Receive(m_CollectionHandle);
}