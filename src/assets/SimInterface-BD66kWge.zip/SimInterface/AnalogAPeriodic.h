

#pragma once
#include "AnalogMessage.h"
#include <iostream>
#include <vector>

class AnalogAPeriodic
{
    protected:
        VIPAnalog_MessageHandle m_AnalogHandle;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialiseAPeriodic
        //
        // Initialise the class with a valid VIPAnalog_Handle
        /// <summary>
        /// Initialise the class
        /// </summary>
        void initialiseAPeriodic(VIPAnalog_MessageHandle aAnalogHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
        AnalogAPeriodic();
       
        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Sends the message/collection
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the message/collection
        /// </summary>
        VIP_Result receive();
};