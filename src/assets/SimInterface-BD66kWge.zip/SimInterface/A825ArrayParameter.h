#pragma once
#include "A825ParameterBase.h"
#include "VIPSimKernal.h"
#include "VIPSimA825.h"
#include <iostream>
#include <string>

template <typename T, VIP_Type VIPTYPE>
class A825ArrayParameter : public A825ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A825ArrayParameter(VIP825_MessageHandle aMessageHandle, std::string aName)
        : A825ParameterBase(aMessageHandle, aName)
    {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getArray
    //
    /// <summary>
    /// Get Array from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result getArray(VIP_UInt32 aMaxLength, T* aData, VIP_UInt32* aDataLength);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setArray
    //
    /// <summary>
    /// Set the VIP Array (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setArray(T* aData, VIP_UInt32 aDataLength);
};
