#pragma once

#include "A825Message.h"
#include "PeriodicBase.h"
#include <iostream>
#include <vector>

class A825Periodic : public PeriodicBase
{
    protected:
        VIP825_MessageHandle m_messageHandle;
        VIP_UInt8 m_receivedFlag;

        

    public:

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// constructor
        /// </summary>
        A825Periodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodic
        //
        /// <summary>
        /// Stop sending periodic word
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodic
        //
        /// <summary>
        /// start sending periodic word 
        /// </summary>
        VIP_Result startPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Collection Receive Flag 
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Collection Receive Flag 
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialisePeriodic
        //
        /// <summary>
        /// Initialise Periodic Class with a valid VIP_CollectionHandle and the VIP_Direction
        /// </summary>
        VIP_Result initialisePeriodic(VIP825_MessageHandle aMessageHandle);
};