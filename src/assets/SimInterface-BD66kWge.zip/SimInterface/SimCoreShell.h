

#pragma once
#include "VIPSimKernal.h"
#include <string>

// Template class that is the base for all VIP protocol objects.
template <typename ObjectT, typename ParentT>
class SimCoreShell
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    SimCoreShell(ParentT aParentHandle, std::string aName)
    {
        m_parentHandle = aParentHandle;
        m_objectHandle = NULL;
        m_objectName = aName;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getTagValueByKey
    //
    /// <summary>
    /// Get the tag value of the VIP object for the specified key name.
    /// </summary>
    VIP_Result getTagValueByKey(const VIP_Char* aKey, VIP_Char* aValue, VIP_UInt32 aMaxLength)
    {
        return VIP_GetTagValueByKey( m_objectHandle, aKey, aValue, aMaxLength);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Destructor
    //
    virtual ~SimCoreShell() {};

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getHandle
    //
    /// <summary>
    /// Get the VIP handle of this object.
    /// </summary>
    ObjectT getHandle() { return m_objectHandle; }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getParentHandle
    //
    /// <summary>
    /// Get the VIP parent handle of this object.
    /// </summary>
    ParentT getParentHandle() { return m_parentHandle; }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getName
    //
    /// <summary>
    /// Get the name of this VIP object.
    /// </summary>
    const char* getName() { return m_objectName.c_str(); }

protected:
    ObjectT m_objectHandle;

private:
    std::string m_objectName;
    ParentT m_parentHandle;
};
