#include "A825Periodic.h"
#include "VIPSimA825.h"
///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A825Periodic::A825Periodic()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialisePeriodic
//
VIP_Result A825Periodic::initialisePeriodic(VIP825_MessageHandle aMessageHandle)
{
    m_messageHandle = aMessageHandle;
    m_receivedFlag = 0;

    // Link the received flag 
    VIP_Result lResult = VIP825_LinkMessageReceivedFlag(aMessageHandle, &m_receivedFlag);

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodic
//
/// <summary>
/// Stop sending periodic word
/// </summary>
VIP_Result A825Periodic::stopPeriodic()
{
    return VIP825_StopPeriodic(m_messageHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
/// <summary>
/// start sending periodic word 
/// </summary>
VIP_Result A825Periodic::startPeriodic()
{
    return VIP825_StartPeriodic(m_messageHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getReceivedFlag
//
VIP_UInt8 A825Periodic::getReceivedFlag()
{
    return m_receivedFlag;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setReceivedFlag (Used to reset the received flag VIP does not reset the flag, that is the users
// responsibility)
//
void A825Periodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_receivedFlag = aValue;
}