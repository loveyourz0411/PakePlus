

#include "NonProtocolParameterBase.h"


NonProtocolParameterBase::NonProtocolParameterBase(VIP_CollectionHandle aCollectionHandle,
    std::string aName) : SimCoreShell(aCollectionHandle, aName)
{
}


NonProtocolParameterBase::~NonProtocolParameterBase()
{
}


VIP_Result NonProtocolParameterBase::initialise()
{
    VIP_Result lResult;

    // Get the parameter from the collection 
    //lResult = VIP_GetParameter(getParentHandle(), getName(), &m_objectHandle);
    lResult =  VIPUserProtocol_GetParameter(getParentHandle(), getName(), &m_objectHandle);
        
    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - Get NPD Parameter Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
       // lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}