

#pragma once
#include "VIPSimA664Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>

class A664ParameterBase : public SimCoreShell<VIP664_ParameterHandle, VIP664_DatasetHandle>
{
    public:

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Constructor
        /// </summary>
        A664ParameterBase(VIP664_DatasetHandle aDataSetHandle, std::string aName);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        /// <summary>
        /// Destructor
        /// </summary>
        ~A664ParameterBase();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise parameter with the VIP
        /// </summary>
        VIP_Result initialise();
};
