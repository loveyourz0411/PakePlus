
#include "A825ParameterBase.h"
#include "VIPSimA825.h"
///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A825ParameterBase::A825ParameterBase(VIP825_MessageHandle aMessageHandle, std::string aName)
    : SimCoreShell(aMessageHandle, aName)
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A825ParameterBase::~A825ParameterBase()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A825ParameterBase::initialise()
{
    VIP_Result lResult;

    // Get the parameter from the Message.
    lResult = VIP825_Get825Parameter(getParentHandle(), getName(), &m_objectHandle);
        
    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - Get A825 Parameter Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}