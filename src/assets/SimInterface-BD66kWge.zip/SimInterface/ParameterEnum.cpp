

#pragma once
#include "ParameterEnum.h"

//-------------------------------------------------------------------------------------------------
// Get the enumeration value from the lookup table that matches the specified enumeration name.
//
//-------------------------------------------------------------------------------------------------

int ParameterEnum::GetEnumeration(const VIP_Char* aName, const EnumLookup* aLookup,
                                  int aEnumTableElementCount)
{
    for (int i = 0; i < aEnumTableElementCount; i++)
    {
        if (strcmp(aLookup[i].Value, aName) == 0)
        {
            return aLookup[i].ID;
        }
    }
    return -1;
}

//-------------------------------------------------------------------------------------------------
// Get the enumeration name from the lookup table that matches the specified enumeration value.
//
//-------------------------------------------------------------------------------------------------

const char* ParameterEnum::GetEnumerationName(VIP_Int32 enumValue, const EnumLookup* aLookup,
                                              int aEnumTableElementCount)
{
    for (int i = 0; i < aEnumTableElementCount; i++)
    {
        if (enumValue == aLookup[i].ID)
        {
            return aLookup[i].Value;
        }
    }
    return NULL;
}