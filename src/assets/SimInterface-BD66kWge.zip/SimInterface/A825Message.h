﻿
#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA825Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>

class A825Message : public SimCoreShell<VIP825_MessageHandle, VIP_ParticipantHandle>
{
    protected:
        VIP_Direction m_direction;
        VIP_QueueType m_queueType;
        VIP_Int32 m_queueLength;
        VIP_QueueLossType m_queueLossType;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupParameters
        //
        /// <summary>
        /// To be implemented by code generated class to add the parameters to this object
        /// </summary>
        virtual VIP_Result setupParameters() = 0;

        

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setDirection
        //
        /// <summary>
        /// Setup the collection as a publisher or subscriber
        /// </summary>
        VIP_Result setDirection();

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Parameters: ParticipantHandle 
        ///             Name, 
        ///             Direction, 
        ///             QueueType (Optional - this is only used by the subscribing Collections)
        /// </summary>
        A825Message(VIP_ParticipantHandle aParticpantHandle, 
                    std::string aName, 
                    VIP_Direction aDirection, 
                    VIP_QueueType aQueueType = VIP_QueueType_Snapshot,
                    VIP_Int32 aQueueLength = 0,
                    VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        virtual ~A825Message();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getIdentifier
        //
        /// <summary>
        /// Get the A825 message identifier.
        /// </summary>
        VIP_UInt32 getIdentifier();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getData
        //
        /// <summary>
        /// Obtains a message payload as raw data. The complete message payload is returned as a
        /// byte array with length given by aMaxLength.
        /// Parameters: aMaxLength - Maximum data length that may be returned.
        ///             aRawData - Pointer to an array that will receive the data.
        ///             aDataLength - Pointer to a variable that will receive actual data length.
        /// </summary>
        VIP_Result getData(VIP_UInt32 aMaxLength, VIP_UInt8* aRawData, VIP_UInt32* aDataLength);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setData
        //
        /// <summary>
        /// Sets a message payload as raw data. The complete message is set from a byte array 
        /// with length given by aDataLength.
        /// Parameters: aRawData - Pointer to an array holding the data.
        ///             aDataLength - Data length to be set.
        /// </summary>
        VIP_Result setData(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise method to setup the message 
        /// </summary>
        VIP_Result initialise();

};
