
#pragma once
#include "SimCoreShell.h"
#include "A429WordBase.h"
#include "APeriodic.h"
#include "Periodic.h"
#include "VIPBaseTypes.h"
#include "VIPSimA429.h"
#include "VIPSimKernal.h"
#include <iostream>
#include <vector>

class A429Bus : public SimCoreShell<VIP429_BusHandle, VIP_ParticipantHandle>
{
    private:
        std::vector<Periodic*>* m_periodicWords;
        std::vector<APeriodic*>* m_aPeriodicWords;

    protected:
        VIP_Direction m_busDirection;
        VIP_Int32 m_queueLength;
        VIP_QueueLossType m_queueLossType;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupWords
        //
        /// <summary>
        /// To be implemented by code generated class to add the words to this object
        /// </summary>
        virtual VIP_Result setupWords() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addPeriodicWord
        //
        /// <summary>
        /// Add periodic word to internal list
        /// </summary>
        void addPeriodicWord(Periodic* wordObject);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addAPeriodicWord
        //
        /// <summary>
        /// Add APeriodic word to internal list
        /// </summary>
        void addAPeriodicWord(APeriodic* wordObject);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startStopPeriodic
        //
        /// <summary>
        /// Start or Stop periodic words.
        /// </summary>
        VIP_Result startStopPeriodic(VIP_Bool start);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <param name="aVIPDirection">Participant Handle</param>
        /// <param name="aPortName">Port Name</param>
        /// <param name="aDirection">Bus Direction</param>
        /// <param name="a">aQueueLength</param>
        /// <param name="a">aQueueLossType</param>
        A429Bus(VIP_ParticipantHandle aParticipantHandle, 
                std::string aPortName, 
                VIP_Direction aDirection, 
                VIP_Int32 aQueueLength = 0,
                VIP_QueueLossType aQueueLossType = VIP_QueueLossType_Lossy);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429Bus();
        
        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the Bus
        /// </summary>

        VIP_Result initialise();
        
        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the latest data for the Bus.  Can be called multiple times and will return
        /// VIP_NO_DATA if there is no more data
        /// </summary>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send the buses associated words 
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodicWords
        //
        /// <summary>
        /// Stop sending or receiving the periodic Words assigned to this bus
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodicWords
        //
        /// <summary>
        /// Start sending or receiving the periodic Words assigned to this bus
        /// </summary>
        VIP_Result startPeriodic();
};
