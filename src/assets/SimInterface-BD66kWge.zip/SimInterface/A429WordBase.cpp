
#include "A429WordBase.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429WordBase::A429WordBase(VIP429_BusHandle aBusHandle, std::string aWordName)
    : SimCoreShell(aBusHandle, aWordName)
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429WordBase::~A429WordBase()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getSDI Method
//
VIP_UInt32 A429WordBase::getSDI()
{
    VIP_UInt32 lSDI;

    // Call the VIP to Get the SDI field
    VIP429_GetField(getHandle(), VIP429_SDI_Field, &lSDI);

    return lSDI;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setSDI
//
VIP_Result A429WordBase::setSDI(VIP_UInt32 aValue)
{
    // Call the VIP to Set the SDI field
    return VIP429_SetField(getHandle(), VIP429_SDI_Field, aValue);
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// getSSM
//
/// <summary>
/// Gets SSM value
/// </summary>
VIP_UInt32 A429WordBase::getSSM()
{
    VIP_UInt32 lSSM;

    // Call the VIP to Get the SSM field
    VIP429_GetField(getHandle(), VIP429_SSM_Field, &lSSM);

    return lSSM;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setSSM
//
/// <summary>
/// Sets SSM value
/// </summary>
VIP_Result A429WordBase::setSSM(VIP_UInt32 aValue)
{
    // Call the VIP to Set the SDI field
    return VIP429_SetField(getHandle(), VIP429_SSM_Field, aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getParity
//
VIP_UInt32 A429WordBase::getParity()
{
    VIP_UInt32 lParity;

    // Call the VIP to Get the Parity field
    VIP429_GetField(getHandle(), VIP429_Parity_Field, &lParity);

    return lParity;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setParity
//
VIP_Result A429WordBase::setParity(VIP_UInt32 aValue)
{
    return VIP429_SetField(getHandle(), VIP429_Parity_Field, aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getLabel
//
VIP_UInt32 A429WordBase::getLabel()
{
    VIP_UInt32 lData = 0;

    VIP429_GetField(getHandle(), VIP429_Label_Field, &lData);

    return lData;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetDataWord
//
VIP_UInt32 A429WordBase::getDataWord()
{
    VIP_UInt32 lData = 0;

    VIP429_GetField(getHandle(), VIP429_Word_Field, &lData);

    return lData;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetDataWord
//
VIP_Result A429WordBase::setDataWord(VIP_UInt32 value)
{
    return VIP429_SetField(getHandle(), VIP429_Word_Field, value);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetData
//
VIP_UInt32 A429WordBase::getData()
{
    VIP_UInt32 lData = 0;

    VIP429_GetField(getHandle(), VIP429_Data_Field, &lData);

    return lData;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetData
//
VIP_Result A429WordBase::setData(VIP_UInt32 value)
{
    return VIP429_SetField(getHandle(), VIP429_Data_Field, value);
}
