
#pragma once

#include "NonProtocolMessage.h"
#include "VIPSimUserProtocol.h"
#include <iostream>
#include <vector>

class NonProtocolAPeriodic
{
    protected:
        VIP_CollectionHandle m_CollectionHandle;

        // Initialise the class with a valid VIP_CollectionHandle
        void initialiseAPeriodic(VIP_CollectionHandle aCollectionHandle);

    public:

        NonProtocolAPeriodic();     
        // Sends the message/collection 
        VIP_Result send();
        // Receive the message/collection 
        VIP_Result receive();
};