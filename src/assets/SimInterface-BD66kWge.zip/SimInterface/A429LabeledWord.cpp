
#include "A429LabeledWord.h"

#include <iostream>
#include <sstream>

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429LabeledWord::A429LabeledWord(VIP429_BusHandle aBusHandle, std::string aWordName,
    VIP_UInt32 aLabel) : A429WordBase(aBusHandle, aWordName)
{
    m_Label = aLabel;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429LabeledWord::~A429LabeledWord()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise word
//
VIP_Result A429LabeledWord::initialiseWord()
{
    VIP_Result lResult;

    // Create word to get handle
    lResult = VIP429_GetWord(getParentHandle(), getName(), &m_objectHandle);

    if (lResult == VIP_Success)
    {
        // *** Set by Config loader 
        // Set word field 
        // lResult = VIP429_SetField(m_WordHandle, VIP429_Label_Field, m_Label);
        
        if (lResult == VIP_Success)
        {
            VIP_UInt32 field;
            lResult = VIP429_GetField(getHandle(), VIP429_Label_Field, &field);
    
            if (lResult == VIP_Success)
            {
                if (field != m_Label)
                {
                    std::stringstream lMessage;
                    lMessage << "Label Mismatch - Configured Label (";
                    lMessage << m_Label << ") Returned Label (" << field << ")";
                    
                    VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Warning,
                                                                            lMessage.str().c_str());
                }
            }

            // Call SetupParameters to add the parameters to this word
            lResult = setupParameters();
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - A429LabeledWord::initialiseWord VIP429_GetWord: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }

    return lResult;
}
