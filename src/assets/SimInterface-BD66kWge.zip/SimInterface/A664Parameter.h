

#pragma once
#include "A664ParameterBase.h"
#include "VIPSimA664.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class A664Parameter : public A664ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A664Parameter(VIP664_DatasetHandle aDataSetHandle, std::string aName)
        : A664ParameterBase(aDataSetHandle, aName)
    {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Get Value from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    T getValue();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Set the VIP value (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setValue(T aValue);
};