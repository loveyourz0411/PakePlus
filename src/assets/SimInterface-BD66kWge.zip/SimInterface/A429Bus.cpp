

#include "A429Bus.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429Bus::A429Bus(VIP_ParticipantHandle aParticipantHandle,
                 std::string aPortName,
                 VIP_Direction aDirection,
                 VIP_Int32 aQueueLength,
                 VIP_QueueLossType aQueueLossType ) : SimCoreShell(aParticipantHandle, aPortName)
{
    // Initialise values for class
    m_busDirection = aDirection;
    m_queueLength = aQueueLength;
    m_queueLossType = aQueueLossType;

    m_periodicWords = new std::vector<Periodic*>();
    m_aPeriodicWords = new std::vector<APeriodic*>();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429Bus::~A429Bus()
{
    if (m_periodicWords != NULL)
    {
        delete m_periodicWords;
    }
    if (m_aPeriodicWords != NULL)
    {
        delete m_aPeriodicWords;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A429Bus::initialise()
{
    VIP_Result lResult;

    // Get bus from its port
    lResult = VIP429_GetBusFromPort(getParentHandle(), getName(), &m_objectHandle);

    if (lResult == VIP_Success)
    {
        // Call setupWords to add the words to this bus
        lResult = setupWords();
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR - A429Bus::initialise VIP429_GetBusFromPort: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    if (lResult == VIP_Success)
    {
        if (m_busDirection == VIP_Direction_Publish)
        {
            // Set Bus Direction (Publish or Subscribe)
            lResult = VIP429_PublishBus(getHandle());

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Publish Bus Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else if (m_busDirection == VIP_Direction_Subscribe)
        {
            // Set the Queue properties 
            lResult = VIP429_SetQueueLength( getHandle(), m_queueLength, m_queueLossType );

            if (lResult == VIP_Success)
            {
                // Set Bus Direction (Publish or Subscribe)
                lResult = VIP429_SubscribeToBus(getHandle());

                if (lResult != VIP_Success)
                {
                    std::string lMessage;
                    lMessage += "ERROR - Subscribe Bus Failed: ";
                    lMessage += getName();
                    lMessage += " VIP_Result = ";
                    //lMessage += VIP_GetErrorMessage( lResult );
                    VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
                }
            }
            else
            {
                std::string lMessage;
                lMessage += "ERROR - VIP429_SetQueueType Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            lResult = VIP_InvalidOperation;
        }
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addPeriodicWord
//
void A429Bus::addPeriodicWord(Periodic* aWordObject)
{
    if (m_periodicWords != NULL && aWordObject != NULL)
    {
        // Add to periodic list
        m_periodicWords->push_back(aWordObject);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addAPeriodicWord
//
void A429Bus::addAPeriodicWord(APeriodic* aWordObject)
{
    if (m_aPeriodicWords != NULL && aWordObject != NULL)
    {
        // Add to periodic list
        m_aPeriodicWords->push_back(aWordObject);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// receive
//
VIP_Result A429Bus::receive()
{
    return VIP429_ReceiveBus(getHandle());
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// send
//
VIP_Result A429Bus::send()
{
    VIP_Result lResult = VIP_NoData;
    unsigned int lWordNumber=0;
    bool lError = false;

    while (!lError && lWordNumber < m_aPeriodicWords->size())
    {
        // Add word to buffer
        lResult = (*m_aPeriodicWords)[lWordNumber]->addToBusSendBuffer();

        if (lResult != VIP_Success)
        {
            lError = true;
            std::string lMessage;
            lMessage += "A429Bus::send() AddToBusSendBuffer Error VIP_Result = ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }

        lWordNumber++;
    }
    
    // If successfully added the words to the buffer call send buffer
    if (lResult == VIP_Success)
    {
        // Send the Buffer
        lResult = VIP429_SendBuffer(getHandle());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodicWords
//
VIP_Result A429Bus::stopPeriodic()
{
    return startStopPeriodic(false);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodicWords
//
VIP_Result A429Bus::startPeriodic()
{
    return startStopPeriodic(true);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startStopPeriodicWords
//
VIP_Result A429Bus::startStopPeriodic(VIP_Bool start)
{
    VIP_Result lResult = VIP_Success;

    if (m_busDirection == VIP_Direction_Publish)
    {
        int periodicWordCount = m_periodicWords->size();
        // Any periodic words defined?
        if (periodicWordCount == 0)
        {
            // No periodic words, nothing to start.
            lResult = VIP_InvalidOperation;
        }
        else
        {
            // Start/Stop sending periodic words.
            for (int i = 0; i < periodicWordCount; i++)
            {
                Periodic* periodicWord = (*m_periodicWords)[i];

                VIP_Result tempResult = start ? periodicWord->startPeriodic() :
                                                periodicWord->stopPeriodic();
                // Did the start / stop Periodic fail?
                if (tempResult != VIP_Success)
                {
                    // Store the overall failure.
                    lResult = tempResult;
                    // Continue with the other word periodics.
                }
            }
        }
    }
    else if (m_busDirection == VIP_Direction_Subscribe)
    {
        // Start/Stop receiving the periodic Words assigned to this bus.
        lResult = start ? VIP429_StartPeriodic(getHandle()) : VIP429_StopPeriodic(getHandle());
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }
    return lResult;
}