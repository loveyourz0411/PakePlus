

#include "A429Block.h"
#include "VIPSimA664.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A429Block::A429Block( VIP664_MessageHandle aMessageHandle, std::string aName )
    : SimCoreShell( aMessageHandle, aName )
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A429Block::~A429Block()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
VIP_Result A429Block::initialise()
{
    VIP_Result lResult;

    // Get the A429 Block handle 
    lResult = VIP664_Get429Block( getParentHandle(), getName(), &m_objectHandle );

    if ( lResult != VIP_Success )
    {
        std::string lMessage;
        lMessage += "VIP664_Get429Block Error: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage( getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str() );
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetFS
//
VIP_UInt8 A429Block::getFS()
{
    VIP_UInt8 lFS = 0;
    VIP664_GetFS( getHandle(), &lFS );
    return lFS;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetFS
//
void A429Block::setFS( VIP_UInt8 aFS )
{
    VIP664_SetFS( getHandle(), aFS );
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getRaw
//
VIP_Result A429Block::getRaw( VIP_UInt32 aMaxLength, VIP_UInt8* aData, VIP_UInt32* aDataLength )
{
    VIP_Result lResult;

    lResult = VIP664_GetValueUInt8Array( getHandle(), aMaxLength, aData, aDataLength );
   
    if ( lResult != VIP_Success )
    {
        std::string lMessage;
        lMessage += "VIP_GetEncodedValueUInt8Array Error: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage( getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str() );
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setRaw
//
VIP_Result A429Block::setRaw( VIP_UInt8* aData, VIP_UInt16 aDataLength )
{
    VIP_Result lResult;
    
    lResult = VIP664_SetValueUInt8Array( getHandle(), aData, aDataLength );
    if ( lResult != VIP_Success )
    {
        std::string lMessage;
        lMessage += "VIP_SetEncodedValueUInt8Array Error: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage( getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str() );
    }
    
    return lResult;
}
