

#include "A429ParaWord.h"
#include "VIPBaseTypes.h"
#include "VIPSimA664.h"

#include <iostream>
#include <sstream>

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor  
A429ParaWord::A429ParaWord(VIP664_DatasetHandle aDataSetHandle, std::string aName,
                            VIP_UInt32 aLabel ) : SimCoreShell( aDataSetHandle, aName )
{
    m_Label = aLabel;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
A429ParaWord::~A429ParaWord()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getSSM
//
/// <summary>
/// Gets SSM value
/// </summary>
VIP_UInt8 A429ParaWord::getSSM()
{
    VIP_UInt8 lSSM;

    // Call the VIP to Get the SSM field
    VIP664_GetPara429SSM( getHandle(), &lSSM );

    return lSSM;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setSSM
//
/// <summary>
/// Sets SSM value
/// </summary>
VIP_Result A429ParaWord::setSSM( VIP_UInt8 aValue )
{
    // Call the VIP to Set the SSM field
    return VIP664_SetPara429SSM( getHandle(), aValue );
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getSDI
//
/// <summary>
/// Gets SDI value
/// </summary>
VIP_UInt8 A429ParaWord::getSDI()
{
    VIP_UInt8 lSDI;

    // Call the VIP to Get the SDI field
    VIP664_GetPara429SDI( getHandle(), &lSDI );

    return lSDI;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setSDI
//
/// <summary>
/// Sets SDI value
/// </summary>
VIP_Result A429ParaWord::setSDI( VIP_UInt8 aValue )
{
    // Call the VIP to Set the SDI field
    return VIP664_SetPara429SDI( getHandle(), aValue );
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getParity
//
/// <summary>
/// Gets parity value
/// </summary>
VIP_Bool A429ParaWord::getParity()
{
    VIP_Bool lParity = VIP_Success;

    // Call the VIP to Get the parity field
    //VIP664_GetPara429Parity( getHandle(), &lParity );

    return lParity;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setParity
//
/// <summary>
/// Sets parity value
/// </summary>
VIP_Result A429ParaWord::setParity( VIP_Bool aValue )
{
    // Call the VIP to Set the parity field
    return VIP664_SetPara429Parity( getHandle(), aValue );
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getRaw
//
/// <summary>
/// Gets the word's raw value
/// </summary>
VIP_UInt32 A429ParaWord::getRaw()
{
    VIP_UInt32 lRaw;

    // Call the VIP to Get the raw word
    VIP664_GetRawWordPara429( getHandle(), VIP429_LabelOrder_Wire,  &lRaw );

    return lRaw;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setRaw
//
/// <summary>
/// Sets raw value
/// </summary>
VIP_Result A429ParaWord::setRaw( VIP_UInt32 aData )
{
    // Call the VIP to Set the raw data
    return VIP664_SetRawWordPara429( getHandle(), VIP429_LabelOrder_Wire, aData );
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A429ParaWord::initialise()
{
    VIP_Result lResult;

    // Create word to get handle
    lResult = VIP664_GetPara429Word( getParentHandle(), getName(), &m_objectHandle );

    if ( lResult == VIP_Success )
    {
       /* VIP_UInt32 field;
        lResult = VIP664_GetPara429Field( getHandle(), VIP429_Label_Field, &field );

        if ( lResult == VIP_Success )
        {
            if ( field != m_Label )
            {
                std::stringstream lMessage;
                lMessage << "Label Mismatch - Configured Label (";
                lMessage << m_Label << ") Returned Label (" << field << ")";

                VIP_SendHealthMessage( getParentHandle(), VIP_HealthLevel_Warning,
                    lMessage.str().c_str() );
            }
        }*/

        // Call SetupParameters to add the parameters to this word
        lResult = setupParameters();
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR - A429ParaWord::initialise - VIP664_GetPara429Word: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage( getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str() );
    }

    return lResult;
}