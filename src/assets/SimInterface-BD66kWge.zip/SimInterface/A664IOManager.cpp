
#include "A664IOManager.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
A664IOManager::A664IOManager(VIP_ParticipantHandle aParticipantHandle)
{
    m_ParticipantHandle = aParticipantHandle;

    // Create APeriodic and Periodic message lists 
    m_PeriodicMessages = new std::vector<A664Periodic*>();
    m_aPeriodicMessages = new std::vector<A664APeriodic*>();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// DeConstructor
A664IOManager::~A664IOManager()
{
    if (m_PeriodicMessages != NULL)
    {
        delete m_PeriodicMessages;
    }

    if (m_aPeriodicMessages != NULL)
    {
        delete m_aPeriodicMessages;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// addPeriodicMessage
void A664IOManager::addPeriodicMessage(A664Periodic* aMessage)
{
    // Add periodic message to list 
    if (m_PeriodicMessages != NULL)
    {
        m_PeriodicMessages->push_back(aMessage);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// addAPeriodicMessage
//
void A664IOManager::addAPeriodicMessage(A664APeriodic* aMessage)
{
    // Add APeriodic message to list 
    if (m_aPeriodicMessages != NULL)
    {
        m_aPeriodicMessages->push_back(aMessage);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// receive
VIP_Result A664IOManager::receive()
{
    // Receive aPeriodic Messages 
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( (lResult == VIP_Success || lResult == VIP_NoData) && i < m_aPeriodicMessages->size() )
    {        
        // Call the Receive function of the Message 
        lResult = (*m_aPeriodicMessages)[i]->receive();     
        i++;
    }

    // Return VIP_Success if the last receive call returned VIP_NoData 
    // as this is still a successfull receive.
    // if the while loop quit due to an error then just return it.
    if (lResult == VIP_NoData)
        lResult = VIP_Success;

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// send
VIP_Result A664IOManager::send()
{
    // Send aPeriodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_aPeriodicMessages->size() )
    {        
        // Call the Send function of the Message 
        lResult = (*m_aPeriodicMessages)[i]->send();     
        i++;
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodicMessages
VIP_Result A664IOManager::stopPeriodicMessages()
{
    // Stop Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the stopPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->stopPeriodic();    
        i++;
    }

    return lResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodicMessages
VIP_Result A664IOManager::startPeriodicMessages()
{
    // Start Periodic Messages
    VIP_Result lResult = VIP_Success;
    unsigned int i = 0;

    while ( lResult == VIP_Success && i < m_PeriodicMessages->size() )
    {        
        // Call the startPeriodic function of the Message 
        lResult = (*m_PeriodicMessages)[i]->startPeriodic();    
        i++;
    }

    return lResult;
}

