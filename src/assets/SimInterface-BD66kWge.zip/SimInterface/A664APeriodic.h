

#pragma once
#include "A664Message.h"
#include <iostream>
#include <vector>

class A664APeriodic
{
    protected:
        VIP664_MessageHandle m_MessageHandle;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialiseAPeriodic
        //
        // Initialise the class with a valid VIP_CollectionHandle
        /// <summary>
        /// Initialise the class 
        /// </summary>
        void initialiseAPeriodic(VIP664_MessageHandle aMessageHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
        A664APeriodic();
       
        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Sends the message
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the message
        /// </summary>
        VIP_Result receive();
};
