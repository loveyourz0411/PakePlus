

#include "A664ArrayParameter.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// getArray template function Specialisation
//
/// <summary>
/// getArray template function Specialisation for VIP_Char Array parameter
/// </summary>
template<>
VIP_Result A664ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    getArray(VIP_UInt32 aMaxLength, VIP_Char* aData, VIP_UInt32* aDataLength)
{
    return VIP664_GetValueString(getHandle(), aMaxLength, aData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setArray template function Specialisation
//
/// <summary>
/// setArray template function Specialisation for VIP_Char Array parameter
/// </summary>
template<>
VIP_Result A664ArrayParameter<VIP_Char, VIP_Type_CharArray>::
    setArray(const VIP_Char* aData, VIP_UInt32 aDataLength)
{
    return VIP664_SetValueString(getHandle(), aData, aDataLength);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getArray template function Specialisation
//
/// <summary>
/// getArray template function Specialisation for VIP_UInt8 Array parameter
/// </summary>
template<>
VIP_Result A664ArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
    getArray(VIP_UInt32 aMaxLength, VIP_UInt8* aData, VIP_UInt32* aDataLength)
{
    //return VIP664_GetValueOpaque(getHandle(), aMaxLength, aData, aDataLength);
    return VIP664_GetValueUInt8Array(getHandle(), aMaxLength, aData, aDataLength);
    
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setArray template function Specialisation
//
/// <summary>
/// setArray template function Specialisation for VIP_UInt8 Array parameter
/// </summary>
template<>
VIP_Result A664ArrayParameter<VIP_UInt8, VIP_Type_UInt8Array>::
    setArray(const VIP_UInt8* aData, VIP_UInt32 aDataLength)
{
    //return VIP664_SetValueOpaque(getHandle(), aData, aDataLength);
    return VIP664_SetValueUInt8Array(getHandle(), aData, aDataLength);
}