

#pragma once
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include "VIPSimUserProtocol.h"
#include <iostream>

class NonProtocolParameterBase : public SimCoreShell<VIP_ParameterHandle, VIP_CollectionHandle>
{
    public:
     
        NonProtocolParameterBase(VIP_CollectionHandle aCollectionHandle, std::string aName);

        ~NonProtocolParameterBase();

        /// Initialise parameter with the VIP
        VIP_Result initialise();
};
