
#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA664Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"

class A429Block : public SimCoreShell<VIP664_429blockHandle, VIP664_MessageHandle>
{
    public:
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        A429Block( VIP664_MessageHandle aMessageHandle, std::string aName );
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429Block();
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the block with the VIP
        /// </summary>
        VIP_Result initialise();
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // GetFS
        //
        /// <summary>
        /// Returns the Functional Status Byte of this A429 block
        /// </summary>
        VIP_UInt8 getFS();
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // GetFS
        //
        /// <summary>
        /// Sets the Functional Status Byte of this A429 block
        /// </summary>
        void setFS( VIP_UInt8 );
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // getRaw
        //
        /// <summary>
        /// Returns the raw data of this A429 block in an array of bytes
        /// </summary>
        VIP_Result getRaw( VIP_UInt32 aMaxLength, VIP_UInt8* aData, VIP_UInt32* aDataLength );

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setRaw
        //
        /// <summary>
        /// Sets the raw data of this A429 block
        /// </summary>
        VIP_Result setRaw( VIP_UInt8* aData, VIP_UInt16 aDataLength );
};
