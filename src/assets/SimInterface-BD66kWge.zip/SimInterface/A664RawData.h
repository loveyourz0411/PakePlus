

#pragma once
#include "VIPSimA664.h"


class A664RawData
{
private:
    VIP664_MessageHandle m_messageHandle;
    VIP_Int32 m_sizeInBytes;

public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Contructor
    /// </summary>
    A664RawData(VIP664_MessageHandle aMessageHandle, VIP_Int32 aSizeInBytes);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Contructor
    /// </summary>
    virtual ~A664RawData() {}

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Obtains a message payload as raw data. The complete message payload is returned, from 
    /// the first FS field, to the last DataParameter, as a byte array with length given by
    /// aMaxLength.
    /// Parameters: aMaxLength - Maximum data length that may be returned.
    ///             aRawData - Pointer to an array that will receive the data.
    ///             aDataLength - Pointer to a variable that will receive actual data length.
    /// </summary>
    VIP_Result getValue(VIP_Int32 aMaxLength, VIP_UInt8* aRawData, VIP_Int32* aDataLength);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Sets a message payload as raw data. The complete message is set from a byte array 
    /// ith length given by aDataLength.
    /// Parameters: aRawData - Pointer to an array holding the data.
    ///             aDataLength - Data length to be set.
    /// </summary>
    VIP_Result setValue(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength);

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // sizeInBytes
    //
    /// <summary>
    /// Get the size of the message payload in bytes.
    /// </summary>
    VIP_Int32 sizeInBytes();
};
