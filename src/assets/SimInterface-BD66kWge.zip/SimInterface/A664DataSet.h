

#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA664Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>

class A664Dataset : public SimCoreShell<VIP664_DatasetHandle, VIP664_MessageHandle>
{
    protected:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupParameters
        //
        /// <summary>
        /// To be implemented by code generated class to add the parameters to this dataset object
        /// </summary>
        virtual VIP_Result setupParameters() = 0;

    public:

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        A664Dataset(VIP664_MessageHandle aMessageHandle, std::string aName);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A664Dataset();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise method to setup the dataset 
        /// </summary>
        VIP_Result initialise();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // GetFS
        //
        /// <summary>
        /// Returns the Functional Status Byte of this dataset
        /// </summary>
        VIP_UInt8 getFS();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // GetFS
        //
        /// <summary>
        /// Sets the Functional Status Byte of this dataset
        /// </summary>
        void setFS(VIP_UInt8);
};
