
#include "A664ParameterBase.h"
#include "VIPSimA664.h"


//////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
A664ParameterBase::A664ParameterBase(VIP664_DatasetHandle aDataSetHandle, std::string aName)
    : SimCoreShell(aDataSetHandle, aName)
{
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
A664ParameterBase::~A664ParameterBase()
{
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
VIP_Result A664ParameterBase::initialise()
{
    VIP_Result lResult;
    // Get Data Parameter Handle
    lResult = VIP664_Get664Parameter(getParentHandle(), getName(), &m_objectHandle);

    if (lResult != VIP_Success)
    {
        std::string lMessage;
        lMessage += "ERROR - Get 664 Parameter Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}
