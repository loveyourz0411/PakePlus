    

#pragma once
#include "A429WordBase.h"
#include <iostream>
#include <vector>

class APeriodic 
{
    friend class A429Bus;

    private:
        A429WordBase* m_word;

        // Word Received flag used for freshness
        VIP_UInt8 m_receivedFlag;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // addToBusSendBuffer
        //
        /// <summary>
        /// Adds word to send buffer
        /// </summary>
        VIP_Result addToBusSendBuffer();

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
        APeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialiseAPeriodic
        //
        /// <summary>
        /// Initialise the class
        /// </summary>
        VIP_Result initialiseAPeriodic(A429WordBase*);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Word Receive Flag
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Word Receive Flag
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send the A429 word immediately.
        /// </summary>
        VIP_Result send();
};
