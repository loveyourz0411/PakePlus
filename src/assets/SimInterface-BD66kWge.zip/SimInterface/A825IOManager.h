#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA825.h"
#include "VIPSimKernal.h"
#include "A825Bus.h"
#include <iostream>
#include <vector>

class A825DataIOManager
{
    private:
        std::vector<A825Bus*>* m_buses;

    protected:
        VIP_ParticipantHandle m_participantHandle;

        void addBus(A825Bus* aBusObject);
       
        
    public:
        A825DataIOManager(VIP_ParticipantHandle aParticipantHandle);
        virtual ~A825DataIOManager();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupIO
        //
        /// <summary>
        /// setupIO virtual function used to setup the messages
        /// </summary>
        virtual VIP_Result setupIO() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Receive
        //
        /// <summary>
        /// Receives all the messages
        /// If an error is returned by one of the messages the method returns immediately with the
        /// VIP result error.
        /// Therefore it will not attempt to receive the rest of the messages in the list. If all
        /// the messages were received without error (even if no new data was received) the
        /// method returns VIP_Success
        /// </summary>
        /// <returns>A VIP_Result value</returns>
        /// <list> 
        /// <item>VIP_Success - All messages were received The operation completed 
        /// successfully.</item>
        /// <item>VIP_BadHandle - A message handle was invalid.</item>
        /// <item>VIP_InvalidOperation - The message is not published, or is periodic</item>
        /// </list>
        VIP_Result receive();

        ////////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Send NPD Messages
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startAllPeriodics
        //
        /// <summary>
        /// Starts all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result startAllPeriodics();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopAllPeriodics
        //
        /// <summary>
        /// Stops all the periodic messages (sending and receiving)
        /// </summary>
        VIP_Result stopAllPeriodics();
};
