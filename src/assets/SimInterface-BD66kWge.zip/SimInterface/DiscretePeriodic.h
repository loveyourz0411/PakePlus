

#pragma once
#include "DiscreteMessage.h"
#include <iostream>
#include <vector>

class DiscretePeriodic
{
    protected:
        VIPDiscrete_MessageHandle m_DiscreteHandle;
        VIP_UInt8 m_ReceivedFlag;
        VIP_Direction m_Direction;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialisePeriodic
        //
        /// <summary>
        /// Initialise Periodic Class with a valid VIPDiscrete_Handle
        /// </summary>
        VIP_Result initialisePeriodic(VIPDiscrete_MessageHandle aDiscreteHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// constructor
        /// </summary>
        DiscretePeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodic
        //
        /// <summary>
        /// Stop sending periodic message
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodic
        //
        /// <summary>
        /// start sending periodic message 
        /// </summary>
        VIP_Result startPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Collection Receive Flag 
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Collection Receive Flag 
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);
};