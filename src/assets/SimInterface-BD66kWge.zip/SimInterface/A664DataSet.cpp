

#include "A664DataSet.h"
#include "VIPSimA664.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
A664Dataset::A664Dataset(VIP664_MessageHandle aMessageHandle, std::string aName)
    : SimCoreShell(aMessageHandle, aName)
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
A664Dataset::~A664Dataset()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
VIP_Result A664Dataset::initialise()
{
    VIP_Result lResult;

    // Get the Dataset handle 
    lResult = VIP664_GetDataset(getParentHandle(), getName(), &m_objectHandle);

    if (lResult == VIP_Success)
    {
        // Call virtual setupParameters method
        lResult = setupParameters();
    }
    else
    {
        std::string lMessage;
        lMessage += "VIP664_GetDataset Error: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetFS
//
VIP_UInt8 A664Dataset::getFS()
{
    VIP_UInt8 lFS = 0;
    VIP664_GetFS(getHandle(), &lFS);
    return lFS;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetFS
void A664Dataset::setFS(VIP_UInt8 aFS)
{
    VIP664_SetFS(getHandle(), aFS);
}
