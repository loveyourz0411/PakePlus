
#pragma once

#include "A664Message.h"
#include "PeriodicBase.h"

class A664Periodic : public PeriodicBase
{
    protected:
        VIP664_MessageHandle m_MessageHandle;
        VIP_UInt8 m_ReceivedFlag;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialisePeriodic
        //
        /// <summary>
        /// Initlaise Periodic Class with a valid VIP664_MessageHandle
        /// </summary>
        VIP_Result initialisePeriodic(VIP664_MessageHandle aMessageHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// constructor
        /// </summary>
        A664Periodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodic
        //
        /// <summary>
        /// Stop sending periodic Message
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodic
        //
        /// <summary>
        /// start sending periodic Message
        /// </summary>
        VIP_Result startPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Message Receive Flag
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Message Receive Flag
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);
};