

#include "NonProtocolPeriodic.h"


NonProtocolPeriodic::NonProtocolPeriodic()
{
}


VIP_Result NonProtocolPeriodic::initialisePeriodic(VIP_CollectionHandle aCollectionHandle,
    VIP_Direction aDirection)
{
    VIP_Result lResult;

    m_CollectionHandle = aCollectionHandle;
    m_Direction = aDirection;

    // Link the received flag 
    lResult = VIPNDP_LinkMessageReceivedFlag(m_CollectionHandle, &m_ReceivedFlag);

    return lResult;
}



/// Stop sending periodic word
VIP_Result NonProtocolPeriodic::stopPeriodic()
{
    /*return VIP_StopPeriodicCollection(m_CollectionHandle, m_Direction);*/
    return VIPUserProtocol_StopPeriodic(m_CollectionHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
/// <summary>
/// start sending periodic word 
/// </summary>
VIP_Result NonProtocolPeriodic::startPeriodic()
{
    /*return VIP_StartPeriodicCollection(m_CollectionHandle, m_Direction);*/
    return VIPUserProtocol_StartPeriodic(m_CollectionHandle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetReceivedFlag
//
VIP_UInt8 NonProtocolPeriodic::getReceivedFlag()
{
    return m_ReceivedFlag;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetReceivedFlag (Used to reset the received flag VIP does not reset the flag that is the users
// responsibility)
//
void NonProtocolPeriodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_ReceivedFlag = aValue;
}