
#pragma once

#include "VIPBaseTypes.h"
#include "VIPSimA429.h"
#include "A429Bus.h"
#include <iostream>
#include <vector>

class A429IOManager
{
    private:
        std::vector<A429Bus*>* m_buses;
    protected:
        VIP_ParticipantHandle m_ParticipantHandle;
        
        // addBus to be used by SetupIO virtual method to add buses to this object
        void addBus(A429Bus* aBusObject);
        
    public:
        A429IOManager(VIP_ParticipantHandle aParticipantHandle);
        ~A429IOManager();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // SetupIO
        //
        /// <summary>
        /// Virtual function to setup the IO
        /// </summary>
        virtual VIP_Result setupIO() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Receive
        //
        /// <summary>
        /// Receives all the words
        /// If an error is returned by one of the words the method returns immediately with the VIP
        /// result error. Therefore it will not attempt to receive the rest of the words in the
        /// list.  If all the words were received without error (even if no new data was received)
        /// the method returns VIP_Success
        /// </summary>
        /// <returns>A VIP_Result value</returns>
        /// <list> 
        /// <item>VIP_Success - All words received. The operation completed successfully.</item>
        /// <item>VIP_BadHandle - A word handle was invalid.</item>
        /// <item>VIP_InvalidOperation - The word is not published, or is periodic</item>
        /// </list>
        VIP_Result receive();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Send
        //
        /// <summary>
        /// Send Buses
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startAllPeriodics
        //
        /// <summary>
        /// Starts all the periodic words (sending and receiving)
        /// </summary>
        VIP_Result startAllPeriodics();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopAllPeriodics
        //
        /// <summary>
        /// Stops all the periodic words (sending and receiving)
        /// </summary>
        VIP_Result stopAllPeriodics();
};