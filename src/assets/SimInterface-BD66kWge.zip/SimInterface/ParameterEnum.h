

#pragma once
#include <string.h>
#include "VIPBaseTypes.h"

typedef struct
{
    VIP_Int32 ID;
    const VIP_Char* Value;
} EnumLookup;

//-------------------------------------------------------------------------------------------------
// Class that provides methods that lookup values in the enumeration lookup table.
//
//-------------------------------------------------------------------------------------------------
class ParameterEnum
{
public:
    static int GetEnumeration(const VIP_Char* aName, const EnumLookup[],
                              int aEnumTableElementCount);
    static const VIP_Char* GetEnumerationName(int enumValue, const EnumLookup[],
                                              int aEnumTableElementCount);
};

