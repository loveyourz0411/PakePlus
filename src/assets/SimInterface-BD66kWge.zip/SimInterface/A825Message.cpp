#include "A825Message.h"
#include "VIPSimA825.h"
///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
//
A825Message::A825Message(VIP_ParticipantHandle aParticpantHandle, 
                         std::string aName, 
                         VIP_Direction aDirection, 
                         VIP_QueueType aQueueType,
                         VIP_Int32 aQueueLength,
                         VIP_QueueLossType aQueueLossType)
                         : SimCoreShell(aParticpantHandle, aName)
{
    m_direction = aDirection;

    m_queueType = aQueueType;
    m_queueLength = aQueueLength;
    m_queueLossType = aQueueLossType;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A825Message::~A825Message()
{
    if (m_direction == VIP_Direction_Publish)
    {
        VIP825_RemovePublisherBus(getParentHandle());
    }
    else
    {
        VIP825_RemoveSubscriberToBus(getParentHandle());
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A825Message::initialise()
{
    VIP_Result lResult;
    
    // Get the collection from the port name 
    // δʵ��
    //lResult = VIP825_GetMessageFromPort(getParentHandle(), getName(), &m_objectHandle);
    // ֱ��ͨ�����ֻ�ȡmsg
    lResult = VIP825_GetMessage(getParentHandle(), getName(), &m_objectHandle);
    if (lResult == VIP_Success)
    {
        // Setup the parameters of this message.
        lResult = setupParameters();
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR - Get A825 Message from PortName Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setDirection 
//
VIP_Result A825Message::setDirection()
{
    VIP_Result lResult;

    if (m_direction == VIP_Direction_Publish)
    {
        // Set Message direction (Publish or Subscribe)
        lResult = VIP825_PublishBus(getParentHandle());

        if (lResult != VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Publish A825 Message Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else if (m_direction == VIP_Direction_Subscribe)
    {
        // Set Queue parameters.
        lResult = VIP825_SetQueueLength(getParentHandle(), m_queueLength, m_queueLossType);

        if (lResult == VIP_Success)
        {
            // Set Message direction (Publish or Subscribe).
            lResult = VIP825_SubscribeToBus(getParentHandle());

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Subscribe A825 Message Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - VIP825_SetQueueLength: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getIdentifier
//
VIP_UInt32 A825Message::getIdentifier()
{
    VIP_UInt32 lIdentifier = 0;
    //TODO ��ȡIDENTIFIER
    //VIP825_GetMessageIdentifier(getHandle(), &lIdentifier);
    return lIdentifier;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getData
VIP_Result A825Message::getData(VIP_UInt32 aMaxLength, VIP_UInt8* aRawData, VIP_UInt32* aDataLength)
{
    return VIP825_GetRawMessage(getHandle(), aMaxLength, aRawData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setData
//
VIP_Result A825Message::setData(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength)
{
    return VIP825_SetRawMessage(getHandle(), aRawData, aDataLength);
}
