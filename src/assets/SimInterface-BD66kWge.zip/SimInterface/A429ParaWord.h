
#pragma once
#include "VIPBaseTypes.h"
#include "VIPSimA664Types.h"
#include "VIPSimKernal.h"
#include "SimCoreShell.h"

class A429ParaWord : public SimCoreShell<VIP664_wordHandle, VIP664_DatasetHandle>
{
    private:
        VIP_UInt32 m_Label;

    protected:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // setupParameters
        //
        /// <summary>
        /// To be implemented by code generated class to add the parameters to this a429 word object
        /// </summary>
        virtual VIP_Result setupParameters() = 0;
    public:
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        A429ParaWord( VIP664_DatasetHandle aDataSetHandle, std::string aName, VIP_UInt32 aLabel );
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429ParaWord();
    
        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the para word with the VIP
        /// </summary>
        VIP_Result initialise();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getSDI
        //
        /// <summary>
        /// Returns the SDI field of this parametric 429 word
        /// </summary>
        VIP_UInt8 getSDI();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setSDI
        //
        /// <summary>
        /// Sets the SDI field of this parametric 429 word
        /// </summary>
        VIP_Result setSDI( VIP_UInt8 aValue );

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getSSM
        //
        /// <summary>
        /// Returns the SSM field of this parametric 429 word
        /// </summary>
        VIP_UInt8 getSSM();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setSSM
        //
        /// <summary>
        /// Sets the SSM field of this parametric 429 word
        /// </summary>
        VIP_Result setSSM( VIP_UInt8 aValue );

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getParity
        //
        /// <summary>
        /// Returns the parity field of this parametric 429 word
        /// </summary>
        VIP_Bool getParity();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setParity
        //
        /// <summary>
        /// Sets the parity field of this parametric 429 word
        /// </summary>
        VIP_Result setParity( VIP_Bool aValue );

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getRaw
        //
        /// <summary>
        /// Returns the raw data of this parametric 429 word
        /// </summary>
        VIP_UInt32 getRaw();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setRaw
        //
        /// <summary>
        /// Sets the raw data of this parametric 429 word
        /// </summary>
        VIP_Result setRaw( VIP_UInt32 aData );
};