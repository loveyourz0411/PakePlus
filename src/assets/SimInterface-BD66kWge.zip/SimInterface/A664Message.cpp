

#include "A664Message.h"
#include "VIPSimA664.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor
A664Message::A664Message(VIP_ParticipantHandle aParticpantHandle,
                         std::string aName,
                         VIP_Int32 aSizeInBytes,
                         VIP_Direction aDirection,
                         VIP_QueueType aQueueType,
                         VIP_Int32 aQueueLength,
                         VIP_QueueLossType aQueueLossType) : SimCoreShell(aParticpantHandle, aName)
{
    m_sizeInBytes = aSizeInBytes;
    m_direction = aDirection;

    m_queueType = aQueueType;
    m_queueLength = aQueueLength;
    m_queueLossType = aQueueLossType;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
A664Message::~A664Message()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
VIP_Result A664Message::initialise()
{
    VIP_Result lResult;
    
    // Get Message handle.
    lResult = VIP664_GetMessageFromPort(getParentHandle(), getName(), &m_objectHandle);
    
    if (lResult ==  VIP_Success)
    {
        // Call virtual method to setup the message's data.
        lResult = setupData();
        if (lResult !=  VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Get A664 Message (collection) from PortName Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR  - Get A664 Message (collection) from PortName Failed: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetMessageVLID
VIP_UInt16 A664Message::getMessageVLID()
{
    VIP_UInt16 lVLID = 0;

    VIP664_GetVLIDFromMessage(getHandle(), &lVLID);

    return lVLID;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setDirection
VIP_Result A664Message::setDirection()
{
    VIP_Result lResult;

    if (m_direction == VIP_Direction_Publish)
    {
        // Publish the message  
        lResult = VIP664_Publish(getHandle());

        if (lResult != VIP_Success)
        {
            std::string lMessage;
            lMessage += "ERROR - Publishing A664 Message Failed: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }
    }
    else if (m_direction == VIP_Direction_Subscribe)
    {
        // Set QueueType here
        lResult = VIP664_SetQueueLength(getHandle(), m_queueLength, m_queueLossType);

        if (lResult == VIP_Success)
        {
            // Subscribe to Message
            //lResult = VIP664_SubscribeToMessage( getHandle(), m_queueType );
            lResult = VIP664_Subscribe(getHandle());

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Subscribe to A664 Message: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            std::string lMessage;
            lMessage += "ERROR - VIP664_SetQueueLength: ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }

    }
    else
    {
        lResult = VIP_InvalidOperation;
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getData
VIP_Result A664Message::getData(VIP_UInt32 aMaxLength, VIP_UInt8* aRawData, VIP_UInt32* aDataLength)
{
    return VIP664_GetRawMessage(getHandle(), aMaxLength, aRawData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setData
//
VIP_Result A664Message::setData(const VIP_UInt8* aRawData, VIP_UInt16 aDataLength)
{
    return VIP664_SetRawMessage(getHandle(), aRawData, aDataLength);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// sizeInBytes
//
VIP_Int32 A664Message::sizeInBytes()
{
    return m_sizeInBytes;
}
