

#include "Periodic.h"
#include "VIPSimKernal.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
// Periodic Constructor
//
Periodic::Periodic()
{
    m_word = NULL;
    m_receivedFlag = 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialisePeriodic
//
VIP_Result Periodic::initialisePeriodic(A429WordBase* aWord)
{
    m_word = dynamic_cast<A429WordBase*>(aWord);

    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        lResult = VIP429_LinkWordReceivedFlag(m_word->getHandle(), &m_receivedFlag);
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setPeriod
//
VIP_Result Periodic::setPeriod(VIP_UInt16 aPeriodMs)
{
    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        lResult = VIP429_SetPeriod(m_word->getHandle(), aPeriodMs);
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodic
//
VIP_Result Periodic::stopPeriodic()
{
    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        // Stop periodic word
        lResult = VIP429_StopPeriodic(m_word->getHandle());
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodic
//
VIP_Result Periodic::startPeriodic()
{
    VIP_Result lResult = VIP_InvalidOperation;
    if (m_word != NULL)
    {
        // Start periodic word
        lResult = VIP429_StartPeriodic(m_word->getHandle());
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// GetReceivedFlag
//
VIP_UInt8 Periodic::getReceivedFlag()
{
    return m_receivedFlag;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// SetReceivedFlag
//
void Periodic::setReceivedFlag(VIP_UInt8 aValue)
{
    m_receivedFlag = aValue;
}
