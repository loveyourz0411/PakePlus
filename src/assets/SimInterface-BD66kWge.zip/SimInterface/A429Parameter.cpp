
#include "A429Parameter.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Bool A429Parameter<VIP_Bool, VIP_Type_Bool>::getValue()
{
    VIP_Bool lValue = false;

    VIP429_GetValueBool(getHandle(), &lValue);

    return lValue;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Bool parameter
/// </summary>
template<>
VIP_Result A429Parameter<VIP_Bool, VIP_Type_Bool>::setValue(VIP_Bool aValue)
{
    return VIP429_SetValueBool(getHandle(), aValue);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Char parameter
/// </summary>
template<>
VIP_Char A429Parameter<VIP_Char, VIP_Type_Char>::getValue()
{
    VIP_Char lValue = 0;

    VIP429_GetValueChar(getHandle(), &lValue);

    return lValue;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Char parameter
/// </summary>
template<>
VIP_Result A429Parameter<VIP_Char, VIP_Type_Char>::setValue(VIP_Char aValue)
{
    return VIP429_SetValueChar(getHandle(), aValue);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Float A429Parameter<VIP_Float, VIP_Type_Float>::getValue()
{
    VIP_Float lValue = 0;

    VIP429_GetValueFloat(getHandle(), &lValue);

    return lValue;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Float parameter
/// </summary>
template<>
VIP_Result A429Parameter<VIP_Float, VIP_Type_Float>::setValue(VIP_Float aValue)
{
    return VIP429_SetValueFloat(getHandle(), aValue);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Double A429Parameter<VIP_Double, VIP_Type_Double>::getValue()
{
    VIP_Double lValue = 0;

    VIP429_GetValueDouble(getHandle(), &lValue);

    return lValue;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Double parameter
/// </summary>
template<>
VIP_Result A429Parameter<VIP_Double, VIP_Type_Double>::setValue(VIP_Double aValue)
{
    return VIP429_SetValueDouble(getHandle(), aValue);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// getValue template function Specialisation
//
/// <summary>
/// getValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Int32 A429Parameter<VIP_Int32, VIP_Type_Int32>::getValue()
{
    VIP_Int32 lValue = 0;

    VIP429_GetValueInt32( getHandle(), &lValue );

    return lValue;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// setValue template function Specialisation
//
/// <summary>
/// setValue template function Specialisation for VIP_Int32 parameter
/// </summary>
template<>
VIP_Result A429Parameter<VIP_Int32, VIP_Type_Int32>::setValue( VIP_Int32 aValue )
{
    return VIP429_SetValueInt32( getHandle(), aValue );
}
