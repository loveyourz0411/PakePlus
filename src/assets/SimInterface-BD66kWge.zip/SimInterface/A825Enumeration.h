#pragma once
#include "A825ParameterBase.h"
#include "ParameterEnum.h"
#include "VIPSimKernal.h"

template <typename T, const EnumLookup* lookupT, int lookupSize>
class A825Enumeration : public A825ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A825Enumeration(VIP_CollectionHandle aCollectionHandle, std::string aName)
        : A825ParameterBase(aCollectionHandle, aName)
    {
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Get Value from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    T getValue()
    {
        VIP_Char lValue[256];
        VIP_Result lResult =
            VIP825_GetValueEnumeration(getHandle(), sizeof(lValue), lValue);

        if (lResult == VIP_Success)
        {
            T enumValue =
                static_cast<T>(ParameterEnum::GetEnumeration(lValue, lookupT, lookupSize));
            return enumValue;
        }
        // 0 is pre-allocated in the enumeration as undefined.
        return static_cast<T>(0x7FFFFFFF);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Set the VIP value (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setValue(T aValue)
    {
        const VIP_Char* lEnumName =
            ParameterEnum::GetEnumerationName(aValue, lookupT, lookupSize);

        if (lEnumName != NULL)
        {
            return VIP825_SetValueEnumeration(getHandle(), lEnumName);
        }
        return VIP_ItemNotFound;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValueID
    //
    /// <summary>
    /// Get Value ID from the VIP.
    /// </summary>
    VIP_Int32 getValueID()
    {
        return (VIP_Int32)getValue();
    }

	///////////////////////////////////////////////////////////////////////////////////////////////
    // setValueID
    //
    /// <summary>
    /// Set the enumeration value ID.
    /// </summary>
    VIP_Result setValueID(VIP_Int32 aValue)
    {
        return setValue((T) aValue);
    }
};