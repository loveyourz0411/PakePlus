
#pragma once

#include "VIPBaseTypes.h"
#include "VIPSimA429.h"
#include "SimCoreShell.h"
#include <iostream>
#include <vector>
#include <string>

class A429WordBase : public SimCoreShell<VIP429_WordHandle, VIP429_BusHandle>
{
    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// </summary>
        /// <param name="aVIPDirection">Bus Handle</param>
        /// <param name="aWordName">Word Name</param>
        /// <param name="aLabel">Label</param>
        A429WordBase(VIP429_BusHandle aBusHandle, std::string aWordName);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // Destructor
        //
        ~A429WordBase();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialise
        //
        /// <summary>
        /// Initialise the word with the VIP
        /// </summary>
        virtual VIP_Result initialiseWord() = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getSDI 
        //
        /// <summary>
        /// Gets SDI value
        /// </summary>
        VIP_UInt32 getSDI();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setSDI
        //
        /// <summary>
        /// Sets SDI value
        /// </summary>
        VIP_Result setSDI(VIP_UInt32 aValue);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getSSM
        //
        /// <summary>
        /// Gets SSM value
        /// </summary>
        VIP_UInt32 getSSM();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setSSM
        //
        /// <summary>
        /// Set SSM value
        /// </summary>
        VIP_Result setSSM(VIP_UInt32 aValue);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getParity
        //
        /// <summary>
        /// Gets the Parity value
        /// </summary>
        VIP_UInt32 getParity();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setParity
        //
        /// <summary>
        /// Sets the Parity value
        /// </summary>
        VIP_Result setParity(VIP_UInt32 aValue);

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getLabel
        //
        /// <summary>
        /// Gets the Label value
        /// </summary>
        VIP_UInt32 getLabel();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getDataWord
        //
        /// <summary>
        /// Returns the raw data word
        /// </summary>
        VIP_UInt32 getDataWord();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setDataWord
        //
        /// <summary>
        /// Sets the raw data word
        /// </summary>
        VIP_Result setDataWord(VIP_UInt32 value); 

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getData
        //
        /// <summary>
        /// Returns the raw The 19 bit data field of the word 
        /// </summary>
        VIP_UInt32 getData();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setData
        //
        /// <summary>
        /// Sets the raw 19 bit data field part of the word
        /// </summary>
        VIP_Result setData(VIP_UInt32 value);
};