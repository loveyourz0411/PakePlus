﻿#include "A825Bus.h"

A825Bus::A825Bus(VIP_ParticipantHandle aParticipantHandle,
                 std::string aPortName,
                 VIP_Direction aDirection,
                 VIP_Int32 aQueueLength,
                 VIP_QueueLossType aQueueLossType ) : SimCoreShell(aParticipantHandle, aPortName)
{
    // Initialise values for class
    m_busDirection = aDirection;
    m_queueLength = aQueueLength;
    m_queueLossType = aQueueLossType;

    m_periodicMsgs = new std::vector<A825Periodic*>();
    m_aPeriodicMsgs = new std::vector<A825APeriodic*>();
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// Destructor
//
A825Bus::~A825Bus()
{
    if (m_periodicMsgs != NULL)
    {
        delete m_periodicMsgs;
    }
    if (m_aPeriodicMsgs != NULL)
    {
        delete m_aPeriodicMsgs;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// initialise
//
VIP_Result A825Bus::initialise()
{
    VIP_Result lResult;

    // Get bus from its port
    lResult = VIP825_GetBusFromPort(getParentHandle(), getName(), &m_objectHandle);

    if (lResult == VIP_Success)
    {
        // Call setupMsgs to add the words to this bus
        lResult = setupMessage();
    }
    else
    {
        std::string lMessage;
        lMessage += "ERROR - A825Bus::initialise VIP825_GetBusFromPort: ";
        lMessage += getName();
        lMessage += " VIP_Result = ";
        //lMessage += VIP_GetErrorMessage( lResult );
        VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
    }

    if (lResult == VIP_Success)
    {
        if (m_busDirection == VIP_Direction_Publish)
        {
            // Set Bus Direction (Publish or Subscribe)
            lResult = VIP825_PublishBus(getHandle());

            if (lResult != VIP_Success)
            {
                std::string lMessage;
                lMessage += "ERROR - Publish Bus Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else if (m_busDirection == VIP_Direction_Subscribe)
        {
            // Set the Queue properties 
            lResult = VIP825_SetQueueLength( getHandle(), m_queueLength, m_queueLossType );

            if (lResult == VIP_Success)
            {
                // Set Bus Direction (Publish or Subscribe)
                lResult = VIP825_SubscribeToBus(getHandle());

                if (lResult != VIP_Success)
                {
                    std::string lMessage;
                    lMessage += "ERROR - Subscribe Bus Failed: ";
                    lMessage += getName();
                    lMessage += " VIP_Result = ";
                    //lMessage += VIP_GetErrorMessage( lResult );
                    VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
                }
            }
            else
            {
                std::string lMessage;
                lMessage += "ERROR - VIP825_SetQueueType Failed: ";
                lMessage += getName();
                lMessage += " VIP_Result = ";
                //lMessage += VIP_GetErrorMessage( lResult );
                VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
            }
        }
        else
        {
            lResult = VIP_InvalidOperation;
        }
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addPeriodicMsg
//
void A825Bus::addPeriodicMsg(A825Periodic* aMsgObject)
{
    if (m_periodicMsgs != NULL && aMsgObject != NULL)
    {
        // Add to periodic list
        m_periodicMsgs->push_back(aMsgObject);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// addAPeriodicMsg
//
void A825Bus::addAPeriodicMsg(A825APeriodic* aMsgObject)
{
    if (m_aPeriodicMsgs != NULL && aMsgObject != NULL)
    {
        // Add to periodic list
        m_aPeriodicMsgs->push_back(aMsgObject);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// receive
//
VIP_Result A825Bus::receive()
{

    
    return VIP825_Receive(getHandle());
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// send
//
VIP_Result A825Bus::send()
{
    VIP_Result lResult = VIP_NoData;
    unsigned int lMsgNumber=0;
    bool lError = false;

    while (!lError && lMsgNumber < m_aPeriodicMsgs->size())
    {
        
        lResult = (*m_aPeriodicMsgs)[lMsgNumber]->addToBusSendBuffer();

        if (lResult != VIP_Success)
        {
            lError = true;
            std::string lMessage;
            lMessage += "A825Bus::send() AddToBusSendBuffer Error VIP_Result = ";
            lMessage += getName();
            lMessage += " VIP_Result = ";
            //lMessage += VIP_GetErrorMessage( lResult );
            VIP_SendHealthMessage(getParentHandle(), VIP_HealthLevel_Error, lMessage.c_str());
        }

        lMsgNumber++;
    }
    
    // If successfully added the words to the buffer call send buffer
    if (lResult == VIP_Success)
    {
        // Send the Buffer
        lResult = VIP825_SendBuffer(getHandle());
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// stopPeriodicMsgs
//
VIP_Result A825Bus::stopPeriodic()
{
    return startStopPeriodic(false);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startPeriodicMsgs
//
VIP_Result A825Bus::startPeriodic()
{
    return startStopPeriodic(true);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// startStopPeriodicMsgs
//
VIP_Result A825Bus::startStopPeriodic(VIP_Bool start)
{
    VIP_Result lResult = VIP_Success;

    if (m_busDirection == VIP_Direction_Publish)
    {
        int periodicMsgCount = m_periodicMsgs->size();
        // Any periodic words defined?
        if (periodicMsgCount == 0)
        {
            // No periodic words, nothing to start.
            lResult = VIP_InvalidOperation;
        }
        else
        {
            // Start/Stop sending periodic words.
            for (int i = 0; i < periodicMsgCount; i++)
            {
                A825Periodic* periodicMsg = (*m_periodicMsgs)[i];

                VIP_Result tempResult = start ? periodicMsg->startPeriodic() :
                                                periodicMsg->stopPeriodic();
                // Did the start / stop Periodic fail?
                if (tempResult != VIP_Success)
                {
                    // Store the overall failure.
                    lResult = tempResult;
                    // Continue with the other word periodics.
                }
            }
        }
    }
    else if (m_busDirection == VIP_Direction_Subscribe)
    {
        // Start/Stop receiving the periodic Msgs assigned to this bus.
        lResult = start ? VIP825_StartPeriodic(getHandle()) : VIP825_StopPeriodic(getHandle());
    }
    else
    {
        lResult = VIP_InvalidOperation;
    }
    return lResult;
}