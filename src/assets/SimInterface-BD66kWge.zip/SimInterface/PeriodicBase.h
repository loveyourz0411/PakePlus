

#pragma once

#include "VIPBaseTypes.h"

class PeriodicBase
{
public: 
    ///////////////////////////////////////////////////////////////////////////////////////////
    // getReceivedFlag
    //
    /// <summary>
    /// Gets the value of the Word Receive Flag
    /// </summary>
    virtual VIP_UInt8 getReceivedFlag() = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////
    // setReceivedFlag
    //
    /// <summary>
    /// Sets the value of the Word Receive Flag
    /// </summary>
    virtual void setReceivedFlag(VIP_UInt8 aValue) = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////
    // stopPeriodic
    //
    /// <summary>
    /// Stop sending periodic word
    /// </summary>
    virtual VIP_Result stopPeriodic() = 0;

    ///////////////////////////////////////////////////////////////////////////////////////////
    // startPeriodic
    //
    /// <summary>
    /// start sending periodic word
    /// </summary>
    virtual VIP_Result startPeriodic() = 0;
};