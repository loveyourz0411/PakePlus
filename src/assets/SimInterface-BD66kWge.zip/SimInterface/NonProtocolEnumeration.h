

#pragma once
#include "NonProtocolParameterBase.h"
#include "ParameterEnum.h"
#include "VIPSimKernal.h"

template <typename T, const EnumLookup* lookupT, int lookupSize>
class NonProtocolEnumeration : public NonProtocolParameterBase
{
public:

    NonProtocolEnumeration(VIP_CollectionHandle aCollectionHandle, std::string aName)
        : NonProtocolParameterBase(aCollectionHandle, aName)
    {
    }


    /// Get Value from the VIP (This method has specialisation for each VIP Type)
    T getValue()
    {
        VIP_Char lValue[256];
        //VIP_Result lResult = VIP_GetParameterValueEnumeration(getHandle(), sizeof(lValue), lValue);
        
        VIP_Result lResult =  VIPUserProtocol_GetValueEnumeration(getHandle(), sizeof(lValue), lValue);

        if (lResult == VIP_Success)
        {
            T enumValue =
                static_cast<T>(ParameterEnum::GetEnumeration(lValue, lookupT, lookupSize));
            return enumValue;
        }
        // 0 is pre-allocated in the enumeration as undefined.
        return static_cast<T>(0x7FFFFFFF);
    }


    /// Set the VIP value (This method has specialisation for each VIP Type)
    VIP_Result setValue(T aValue)
    {
        const VIP_Char* lEnumName = ParameterEnum::GetEnumerationName(aValue, lookupT, lookupSize);

        if (lEnumName != NULL)
        {
           // return VIP_SetParameterValueEnumeration(getHandle(), lEnumName);
           return VIPUserProtocol_SetValueEnumeration(getHandle(), lEnumName);
        }
        return VIP_ItemNotFound;
    }


    /// Get the enumeration value ID as defined in the configuration.
    VIP_Int32 getValueID()
    {
        return (VIP_Int32)getValue();
    }


    /// Set the enumeration value ID.
    VIP_Result setValueID(VIP_Int32 aValue)
    {
        return setValue((T) aValue);
    }
};