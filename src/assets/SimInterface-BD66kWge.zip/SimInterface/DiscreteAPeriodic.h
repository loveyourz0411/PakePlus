

#pragma once
#include "DiscreteMessage.h"
#include "VIPSimDiscreteTypes.h"
#include <iostream>
#include <vector>

class DiscreteAPeriodic
{
    protected:
        VIPDiscrete_MessageHandle m_DiscreteHandle;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialiseAPeriodic
        //
        // Initialise the class with a valid VIPDiscrete_Handle
        /// <summary>
        /// Initialise the class 
        /// </summary>
        void initialiseAPeriodic(VIPDiscrete_MessageHandle aDiscreteHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// Class Constructor
        /// </summary>
        DiscreteAPeriodic();
       
        ///////////////////////////////////////////////////////////////////////////////////////////
        // send
        //
        /// <summary>
        /// Sends the message/collection 
        /// </summary>
        VIP_Result send();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // receive
        //
        /// <summary>
        /// Receive the message/collection 
        /// </summary>
        VIP_Result receive();
};