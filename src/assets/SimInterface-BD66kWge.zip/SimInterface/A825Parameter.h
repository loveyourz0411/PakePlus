#pragma once
#include "A825ParameterBase.h"
#include "VIPSimA825.h"
#include <iostream>

template <typename T, VIP_Type VIPTYPE>
class A825Parameter : public A825ParameterBase
{
public:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /// <summary>
    /// Constructor
    /// </summary>
    A825Parameter(VIP825_MessageHandle aMessageHandle, std::string aName)
        : A825ParameterBase(aMessageHandle, aName)
    {
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////
    // getValue
    //
    /// <summary>
    /// Get Value from the VIP (This method has specialisation for each VIP Type)
    /// </summary>
    T getValue();

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // setValue
    //
    /// <summary>
    /// Set the VIP value (This method has specialisation for each VIP Type)
    /// </summary>
    VIP_Result setValue(T aValue);
};
