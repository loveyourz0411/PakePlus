

#pragma once
#include "AnalogMessage.h"
#include "PeriodicBase.h"
#include <iostream>
#include <vector>

class AnalogPeriodic : public PeriodicBase
{
    protected:
        VIPAnalog_MessageHandle m_AnalogHandle;
        VIP_UInt8 m_ReceivedFlag;
        VIP_Direction m_Direction;

        ///////////////////////////////////////////////////////////////////////////////////////////
        // initialisePeriodic
        //
        /// <summary>
        /// Initialise Periodic Class with a valid VIPAnalog_Handle
        /// </summary>
        VIP_Result initialisePeriodic(VIPAnalog_MessageHandle aAnalogHandle);

    public:
        ///////////////////////////////////////////////////////////////////////////////////////////
        // Constructor
        //
        /// <summary>
        /// constructor
        /// </summary>
        AnalogPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // stopPeriodic
        //
        /// <summary>
        /// Stop sending periodic message
        /// </summary>
        VIP_Result stopPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // startPeriodic
        //
        /// <summary>
        /// start sending periodic message
        /// </summary>
        VIP_Result startPeriodic();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // getReceivedFlag
        //
        /// <summary>
        /// Gets the value of the Collection Receive Flag
        /// </summary>
        VIP_UInt8 getReceivedFlag();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // setReceivedFlag
        //
        /// <summary>
        /// Sets the value of the Collection Receive Flag
        /// </summary>
        void setReceivedFlag(VIP_UInt8 aValue);
};