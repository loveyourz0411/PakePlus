

#include "NonProtocolParameter.h"


template<>
VIP_Bool NonProtocolParameter<VIP_Bool, VIP_Type_Bool>::getValue()
{
    VIP_Bool lValue = false;

    /*VIP_GetParameterValueBool(getHandle(), &lValue);*/

    VIPUserProtocol_GetValueBool(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Bool, VIP_Type_Bool>::setValue(VIP_Bool aValue)
{
    /*return VIP_SetParameterValueBool(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueBool(getHandle(), aValue);
}


template<>
VIP_Char NonProtocolParameter<VIP_Char, VIP_Type_Char>::getValue()
{
    VIP_Char lValue = 0;

    /*VIP_GetParameterValueChar(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueChar(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Char, VIP_Type_Char>::setValue(VIP_Char aValue)
{
    /*return VIP_SetParameterValueChar(getHandle(), aValue);*/
    return  VIPUserProtocol_SetValueChar(getHandle(), aValue);
}


template<>
VIP_Int8 NonProtocolParameter<VIP_Int8, VIP_Type_Int8>::getValue()
{
    VIP_Int8 lValue = 0;

    /*VIP_GetParameterValueInt8(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueInt8(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Int8, VIP_Type_Int8>::setValue(VIP_Int8 aValue)
{
   /*return VIP_SetParameterValueInt8(getHandle(), aValue);*/ 
   return VIPUserProtocol_SetValueInt8(getHandle(), aValue);
}


template<>
VIP_UInt8 NonProtocolParameter<VIP_UInt8, VIP_Type_UInt8>::getValue()
{
    VIP_UInt8 lValue = 0;

    /*VIP_GetParameterValueUInt8(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueUInt8(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_UInt8, VIP_Type_UInt8>::setValue(VIP_UInt8 aValue)
{
    /*return VIP_SetParameterValueUInt8(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueUInt8(getHandle(), aValue);
}


template<>
VIP_Int16 NonProtocolParameter<VIP_Int16, VIP_Type_Int16>::getValue()
{
    VIP_Int16 lValue = 0;

    /*VIP_GetParameterValueInt16(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueInt16(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Int16, VIP_Type_Int16>::setValue(VIP_Int16 aValue)
{
    /*return VIP_SetParameterValueInt16(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueInt16(getHandle(), aValue);
}


template<>
VIP_UInt16 NonProtocolParameter<VIP_UInt16, VIP_Type_UInt16>::getValue()
{
    VIP_UInt16 lValue = 0;

    /*VIP_GetParameterValueUInt16(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueUInt16(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_UInt16, VIP_Type_UInt16>::setValue(VIP_UInt16 aValue)
{
    /*return VIP_SetParameterValueUInt16(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueUInt16(getHandle(), aValue);
}


template<>
VIP_Int32 NonProtocolParameter<VIP_Int32, VIP_Type_Int32>::getValue()
{
    VIP_Int32 lValue = 0;

    /*VIP_GetParameterValueInt32(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueInt32(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Int32, VIP_Type_Int32>::setValue(VIP_Int32 aValue)
{
    /*return VIP_SetParameterValueInt32(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueInt32(getHandle(), aValue);
}


template<>
VIP_UInt32 NonProtocolParameter<VIP_UInt32, VIP_Type_UInt32>::getValue()
{
    VIP_UInt32 lValue = 0;

   /* VIP_GetParameterValueUInt32(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueUInt32(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_UInt32, VIP_Type_UInt32>::setValue(VIP_UInt32 aValue)
{
    /*return VIP_SetParameterValueUInt32(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueUInt32(getHandle(), aValue);
}


template<>
VIP_Int64 NonProtocolParameter<VIP_Int64, VIP_Type_Int64>::getValue()
{
    VIP_Int64 lValue = 0;

    /*VIP_GetParameterValueInt64(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueInt64(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Int64, VIP_Type_Int64>::setValue(VIP_Int64 aValue)
{
    /*return VIP_SetParameterValueInt64(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueInt64(getHandle(), aValue);
}


template<>
VIP_UInt64 NonProtocolParameter<VIP_UInt64, VIP_Type_UInt64>::getValue()
{
    VIP_UInt64 lValue = 0;

    /*VIP_GetParameterValueUInt64(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueUInt64(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_UInt64, VIP_Type_UInt64>::setValue(VIP_UInt64 aValue)
{
    /*return VIP_SetParameterValueUInt64(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueUInt64(getHandle(), aValue);
}


template<>
VIP_Float NonProtocolParameter<VIP_Float, VIP_Type_Float>::getValue()
{
    VIP_Float lValue = 0;  
    /*VIP_GetParameterValueFloat(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueFloat(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Float, VIP_Type_Float>::setValue(VIP_Float aValue)
{
    /*return VIP_SetParameterValueFloat(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueFloat(getHandle(), aValue);
}


template<>
VIP_Double NonProtocolParameter<VIP_Double, VIP_Type_Double>::getValue()
{
    VIP_Double lValue = 0;

    /*VIP_GetParameterValueDouble(getHandle(), &lValue);*/
    VIPUserProtocol_GetValueDouble(getHandle(), &lValue);

    return lValue;
}


template<>
VIP_Result NonProtocolParameter<VIP_Double, VIP_Type_Double>::setValue(VIP_Double aValue)
{
    /*return VIP_SetParameterValueDouble(getHandle(), aValue);*/
    return VIPUserProtocol_SetValueDouble(getHandle(), aValue);
}
