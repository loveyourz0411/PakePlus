%PauseSaveCheck Checks whether a pause has been conducted as part of a 
%   save state operation. If so serialises the 'Final States' variable
%   and continues the model.
%
%   Simulink version    : 8.0 (R2012b) 20-Jul-2012
%   MATLAB file generated on : 21-Oct-2013 15:13:35

if exist('performingSave', 'var')        
    if exist('xFinal', 'var') 
        save('StateSave.mat', 'xFinal');
        fid = fopen('StateSave.mat');
        StateBytes = fread(fid, inf, 'uint8=>uint8');
        fclose(fid);
        delete('StateSave.mat');
        clear('fid');
    end
    set_param( bdroot(gcb), 'SimulationCommand', 'continue');
    clear performingSave
end
