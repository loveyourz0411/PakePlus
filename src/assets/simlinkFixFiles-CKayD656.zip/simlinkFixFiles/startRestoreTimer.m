%StartRestoreTimer Starts a timer to run the 'restoreSim' script. The
%   script is run in this way to be be executed independently of the 
%   model. This allows the model to be stopped and started again 
%   programmatically for the state to be restored.
%
%   Simulink version    : 8.0 (R2012b) 20-Jul-2012
%   MATLAB file generated on : 21-Oct-2013 15:13:35

t = timer('TimerFcn', @restoreSim, 'ExecutionMode','singleShot', 'startDelay', 1);
start(t);

    
