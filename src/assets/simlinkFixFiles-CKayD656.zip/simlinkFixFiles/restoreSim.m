function restoreSim( obj, event)

%restoreSim Stops the model and starts it again with the saved state.
%
%   Simulink version    : 8.0 (R2012b) 20-Jul-2012
%   MATLAB file generated on : 21-Oct-2013 15:13:35

set_param(evalin('base', 'Simulation_Name'),'SimulationCommand','stop');

%Rehydrate Sim Structure in Base Workspace from serialized bytes, prior to
%restarting model
simstructure = evalin('base', 'RestoreState');

fid = fopen('StateRestore.mat', 'w');
fwrite(fid, simstructure, 'uint8');
fclose(fid);
load('StateRestore.mat', 'xFinal');
%The xFinal loaded has only local scope (within function)
%Need to assign to xFinal in base workspace.
assignin('base', 'xFinal', xFinal);
delete('StateRestore.mat');
clear('fid');

set_param(evalin('base', 'Simulation_Name'), 'LoadInitialState', 'on', 'InitialState', 'xFinal');

assignin('base', 'StateRestored', true);

set_param(evalin('base', 'Simulation_Name'),'SimulationCommand','start');

end