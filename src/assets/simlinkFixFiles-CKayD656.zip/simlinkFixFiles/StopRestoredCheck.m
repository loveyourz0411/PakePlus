if exist('StateRestored', 'var')     
set_param(evalin('base', 'Simulation_Name'), 'LoadInitialState', 'off'); 
clear StateRestored 
end 