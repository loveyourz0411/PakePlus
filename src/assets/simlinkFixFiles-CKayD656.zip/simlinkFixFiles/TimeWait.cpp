

#define S_FUNCTION_NAME TimeWait /* Defines and Includes */
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"

#include <WTypes.h>
#include <WinUser.h>
#include <time.h>
#include <stdint.h>
#include "stdio.h"
#include <iostream>

#ifndef VIP_COMPILED
#include "VIPSimKernal.h"
static LARGE_INTEGER gClockFrequency;
LARGE_INTEGER LastRunCount;

static VIP_State lastCSIState = VIP_State_Unconnected;
static VIP_State currentCSIState = VIP_State_Unconnected;

static UINT32_T lParticipantHandle;

typedef enum
{
    Inactive = 0,
    SavingState = 1,
    RestoringState = 2,
    WaitingRestart = 3,
    WaitingContinue = 4,
} SimulationState;

static SimulationState cInternalState;
static bool cSaveFailure = false;
static const std::string cStateDataName = "StateBytes";
static const VIP_UInt32 cMaxDataLength = 32768;
static const char *cSimulation_Name;

///////////////////////////////////////////////////////////////////////////////////////////////
// getModelName
//
// This method gets the model name. Note that this is run at startup because the bdroot function
// used (no alternative) gets the current root so if the user has selected the model ref then it's
// name shall be returned.
char* getModelName( void )
{
    char *lModelName = NULL;
    mxArray *lPLHS[1];
    mxArray *lPRHS[1];

    lPRHS[0] = NULL;
    lPLHS[0] = NULL;

    if ( mexCallMATLAB( 1, lPLHS, 0,
            lPRHS, "bdroot" ) != 0 )
    {
        mexPrintf( "Failed to get ModelName. \n" );
    }
    else
    {

        if ( lPLHS[0] )
        {
            lModelName = mxArrayToString( lPLHS[0] );
            mxDestroyArray( lPLHS[0] );
            lPLHS[0] = NULL;
        }
    }
    return lModelName;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// checkSaveFinalState
//
// This method ensures that the model preferences are set to capture the SimState on pause.
//
bool checkSaveFinalState( void )
{
    //Need to check that the model configuration is correct.
    bool lResult = false;
    char lSaveFinalStateOn[] = "on";
    mxArray *lPLHS[1];
    mxArray *lPRHS[2];
    char *lBuffer;

    lPRHS[0] = mxCreateString( cSimulation_Name );
    lPRHS[1] = mxCreateString( "SaveFinalState" );
    lPLHS[0] = NULL;

    if ( mexCallMATLAB( 1, lPLHS, 2,
            lPRHS, "get_param" ) != 0 )
    {
        mexPrintf( "Failed to get SaveFinalState parameter value. \n" );
    }
    else
    {
        if ( lPLHS[0] )
        {
            size_t lBufferLength;
            lBufferLength = mxGetN( lPLHS[0] )*sizeof( mxChar )+1;
            lBuffer = static_cast<char*> ( mxMalloc( lBufferLength ) );

            /* Copy the string data into buf. */
            mxGetString( lPLHS[0], lBuffer, ( mwSize )lBufferLength );

            mxDestroyArray( lPLHS[0] );
            lPLHS[0] = NULL;
        }
    }

    if ( strcmp( lBuffer, lSaveFinalStateOn ) == 0)
    {
        lResult = true;
    }
    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// RestoreState
//
// This method carries out the CSI restore process. It gets the state to restore the model to
// from the CSI and places it in a workspace variable. It then starts a timer to execute a
// script to stop the model and restart it using the state variable. Note that it was necessary
// to use a timer to run a script to stop and restart the model independently as it is not possible
// to restart the model otherwise.
bool RestoreState()
{
    cInternalState = RestoringState;

    int lNumColumns = 1; // The number of columns
    VIP_UInt32 lDataLength;
    VIP_UInt8 lData[cMaxDataLength];
    VIP_Result lResult;
    mxArray *lMexArray;
    UINT8_T *lMexData;

    // Retrieve the stored state from the CSI.
    //lResult = VIP_ManualRestoreState( lParticipantHandle );
    lResult = VIP_Success;
    if( lResult == VIP_Success )
    {
        //lResult = VIP_GetBinaryData( lParticipantHandle, cStateDataName.c_str(), lData,
        //                             &lDataLength, cMaxDataLength );
    }
    else
    {
        VIP_SendHealthMessage( lParticipantHandle, VIP_HealthLevel_Information, VIP_GetErrorMessage( lResult ) );
    }

    if (lData == NULL)
    {
        VIP_SendHealthMessage( lParticipantHandle, VIP_HealthLevel_Information, VIP_GetErrorMessage( lResult ) );
        mexPrintf( "Could not get restore state from CSI. \n" );
    }
    else
    {
        lMexArray = mxCreateNumericMatrix( 0, 0, mxUINT8_CLASS, mxREAL );
        lMexData  = static_cast<UINT8_T*> ( mxMalloc( ( lNumColumns*( lDataLength ) ) * sizeof( UINT8_T ) ) );

        if ( lMexData != NULL )
        {
            for ( int i = 0; i < ( int )lDataLength; i++ )
            {
                lMexData[i] = lData[i];
            }

            mxSetData( lMexArray, lMexData );
            mxSetM( lMexArray, ( mwSize )lDataLength);
            mxSetN(lMexArray, ( mwSize )lNumColumns );
            mexPutVariable("base", "RestoreState", lMexArray);
            mxDestroyArray( lMexArray );


            if ( mexCallMATLAB( 0, NULL, 0,
                    NULL, "startRestoreTimer" ) != 0 )
            {
                mexPrintf( "Failed to start restore timer. \n" );
            }
            else
            {
                // Instruct the CSI that we have finished the restore process.
                VIP_ManualRestoreComplete( lParticipantHandle );
            }
        }
    }
    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// ProcessSavingState
//
// This method preforms the initial stage of saving, pausing the model to capture the SimState.
//
bool ProcessSavingState( void )
{
    bool lResult = true;
    VIP_Result lReturnValue = VIP_Success;

    // Start saving the strored state to the CSI.
    //lReturnValue = VIP_ManualSaveState( lParticipantHandle );
    lReturnValue = VIP_Success;
    if ( checkSaveFinalState() == true && lReturnValue == VIP_Success )
    {
        //Need to put a "flag" on the base workspace, so we can get
        //restarted again by script, following the pause.
        mxArray *lMexArray;
        lMexArray = mxCreateNumericMatrix( 0, 0, mxUINT8_CLASS, mxREAL );
        mexPutVariable( "base", "performingSave", lMexArray );
        mxDestroyArray( lMexArray );

        //Need to pause the simulation to capture its state
        mxArray *lPLHS[1];
        mxArray *lPRHS[3];

        lPRHS[0] = mxCreateString( cSimulation_Name );
        lPRHS[1] = mxCreateString( "SimulationCommand" );
        lPRHS[2] = mxCreateString( "pause" );
        lPLHS[0] = NULL;

        if ( mexCallMATLAB( 0, lPLHS, 3,
                lPRHS, "set_param" ) != 0 )
        {
            mexPrintf( "Failed to pause. \n" );
        }

        cInternalState = WaitingContinue;
    }
    else if ( cSaveFailure != true )
    {
        cInternalState = Inactive;
        lResult = false;
        // Set flag to only give the warning once.
        cSaveFailure = true;
        mexPrintf( "Failed to save, Model Configuration Parameter 'SaveFinalState' must be set with name 'xFinal'. \n" );
        VIP_SendHealthMessage( lParticipantHandle, VIP_HealthLevel_Information, VIP_GetErrorMessage( lReturnValue ) );
    }

    return lResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// ProcessSavingState2
//
// This method completes the save process. It gets called once the model has been 'continued',
// sending the SimState to the CSI for storage.
void ProcessSavingState2( void )
{
    VIP_Result lResult = VIP_Success;

    //Now, actually send the data to the CSI for saving centrally
    mxArray *lArray_ptr = mexGetVariable( "base", "StateBytes" );
    if ( lArray_ptr == NULL )
    {
        mexPrintf( "Could not get variable StateBytes from MATLAB workspace. \n" );
    }
    else
    {
        //How big is the array of byte data?
        size_t lElements = mxGetNumberOfElements( lArray_ptr );

        //Grab data from mxArray into a standard byte array
        VIP_UInt8 *lStandardArray = ( uint8_t* ) mxGetData( lArray_ptr );

        //lResult = VIP_SaveBinaryData( lParticipantHandle, cStateDataName.c_str(), lStandardArray, //lElements );

        if ( lResult != VIP_Success )
        {
            VIP_SendHealthMessage( lParticipantHandle, VIP_HealthLevel_Information, VIP_GetErrorMessage( lResult ) );
        }
    }

    // Instruct the CSI that we have finished saving.
    //VIP_ManualSaveComplete( lParticipantHandle );

    cInternalState = Inactive;
    mxDestroyArray( lArray_ptr );
}

///////////////////////////////////////////////////////////////////////////////////////////////
// ProcessRestoringState
//
// This method is called after a restore to get us out of the 'held' while loop, allowing the
// model another iteration of the callback methods to complete the restore process.
//
bool ProcessRestoringState( void )
{
    cInternalState = WaitingRestart;
    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////
// checkForHeld
//
// This method checks wether the participant has been commanded into the held state. If so has
// a save or restored been requested.
//
bool checkForHeld( VIP_State aStateCommand )
{
    bool lReturn = false;
    VIP_Result lResult;
    VIP_Bool lSaveRequested = false;
    VIP_Bool lRestoreRequested = false;

    if ( ( currentCSIState == VIP_State_Held ) && ( cSaveFailure != true ) )
    {
        VIP_SetState( lParticipantHandle, VIP_State_Held );
        lastCSIState = VIP_State_Held;

        if ( VIP_GetStateCommand( lParticipantHandle, &aStateCommand ) == VIP_Success )
        {
            currentCSIState = aStateCommand;
        }

        //Check whether a save is required.
        lResult = VIP_GetSaveRequested( lParticipantHandle, &lSaveRequested );

        if ( lResult == VIP_Success )
        {
            if( lSaveRequested )
            {
                cInternalState = SavingState;
            }
        }
        else
        {
            mexPrintf( "SaveSimulinkState Error: %d\n", lResult );
        }

        //Check whether a restore is required.
        lResult = VIP_GetRestoreRequested( lParticipantHandle, &lRestoreRequested );

        if ( lResult == VIP_Success )
        {
            if( lRestoreRequested )
            {
                RestoreState();
            }
        }
        else
        {
            mexPrintf( "RestoreSimulinkState Error: %d\n", lResult );
        }
    }
    return lReturn;
}
#endif

/* Note, when making a mex, this S-Function must be linked against winmm.lib */

#define MDL_START


///////////////////////////////////////////////////////////////////////////////////////////////
// mdlStart
//
// Simulink callback. Sets up the model and connects the participant. If returning from a restore
// tidys up the variables and remains in held. Otherwise sets the participant into running state.
//
static void mdlStart( SimStruct *S )
{
#ifndef VIP_COMPILED



//Initalise global variables to required values
cInternalState = Inactive;

// Save the model name.
cSimulation_Name = getModelName();
mxArray *lMexArray;
lMexArray = mxCreateString( cSimulation_Name );
mexPutVariable( "base", "Simulation_Name", lMexArray );
mxDestroyArray( lMexArray );

// Get the participant handle from the workspace.  
mxArray *lPLHS[1];
lPLHS[0] = mexGetVariable("base", "ParticipantHandle");

if ( lPLHS[0] )
{
    size_t lBufferLength;
    UINT32_T *lParticipantHandleData;
    lBufferLength = mxGetN( lPLHS[0] )*sizeof( mxChar )+1;
    lParticipantHandleData = static_cast<UINT32_T*> ( mxMalloc( lBufferLength ) );

    /* Copy the string data into buf. */
    lParticipantHandleData = ( UINT32_T * ) mxGetData( lPLHS[0] );
    lParticipantHandle = lParticipantHandleData[0];
    mxDestroyArray( lPLHS[0] );
    lPLHS[0] = NULL;
}

// Suppress warnings created on save/restore.
mxArray *lWarningsPLHS[1];
mxArray *lWarningsPRHS[3];

lWarningsPRHS[0] = mxCreateString( "off" );
lWarningsPRHS[1] = mxCreateString( "Simulink:blocks:AssumingDefaultSimStateForSFcn" );
lWarningsPLHS[0] = NULL;

if ( mexCallMATLAB( 0, lWarningsPLHS, 2,
        lWarningsPRHS, "warning" ) != 0 )
{
    mexPrintf( "Failed to suppress AssumingDefaultSimStateForSFcn warning. \n" );
}
mxDestroyArray( lWarningsPLHS[0] );
mxDestroyArray( lWarningsPRHS[0] );

// Enter Manual Mode
VIP_Result lResult = VIP_EnterManualMode( lParticipantHandle );

if ( lResult != VIP_Success )
{
    mexPrintf( "VIP_StartSimulationInManualMode Error: %d\n", lParticipantHandle );
}
else
{
    // Register as a Save and Restore Participant.
    lResult = VIP_RegisterSaveRestoreManualMode( lParticipantHandle );

    if ( lResult != VIP_Success )
    {
        mexPrintf( "RegisterSaveRestoreManualMode Error: %d\n", lResult );
    }

    // Check whether this start is the result of a restore.
    mxArray *lArray_ptr = mexGetVariable( "base", "StateRestored" );
    if ( lArray_ptr != NULL )
    {
        mexPrintf( "Coming back from restore....\n" );
        mexEvalString( "clear('base','t')" );
        mexEvalString( "clear('base','RestoreState')" );
        mexEvalString( "clear('base','StateBytes')" );
    }
    else
    {
        VIP_SetState( lParticipantHandle, VIP_State_Running );
        currentCSIState = VIP_State_Running;
    }
    mxDestroyArray( lArray_ptr );
}

LastRunCount.QuadPart = -1;

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////
// mdlInitializeSizes
//
// Simulink callback.
//
static void mdlInitializeSizes(SimStruct *S)
{
#ifndef VIP_COMPILED
    ssSetNumSFcnParams(S, 0);
if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S))
{
    return; /* Parameter mismatch reported by the Simulink engine*/
}

if (!ssSetNumInputPorts(S, 0)) return;
//ssSetInputPortWidth(S, 0, DYNAMICALLY_SIZED);
//ssSetInputPortDirectFeedThrough(S, 0, 1);

if (!ssSetNumOutputPorts(S,0)) return;
//ssSetOutputPortWidth(S, 0, DYNAMICALLY_SIZED);

ssSetNumSampleTimes(S, 1);

/* Take care when specifying exception free code - see sfuntmpl.doc */
//ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);

//Get the Clock Frequency
QueryPerformanceFrequency((LARGE_INTEGER*) &gClockFrequency);

timeBeginPeriod(1);

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////
// mdlInitializeSizes
//
// Simulink callback.
//
static void mdlInitializeSampleTimes(SimStruct *S)
{
#ifndef VIP_COMPILED
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
ssSetOffsetTime(S, 0, 0.0);

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////
// mdlOutputs
//
// Simulink callback. Is called continually when the model is running. Controls the model
// interactions with the CSI.
//
static void mdlOutputs(SimStruct *S, int_T tid)
{
#ifndef VIP_COMPILED
    VIP_Result lResult;
VIP_State lStateCommand;
LARGE_INTEGER StartCount;
LARGE_INTEGER CurrentCount;
int DelayInTicks;
int Delta;

//Find out what the sample time is that we are trying to hit
time_T lsampleTime = ssGetSampleTime(S,0);
//mexPrintf("SampleTime in Seconds %f\n", lsampleTime);

lResult = VIP_GetStateCommand( lParticipantHandle, &lStateCommand);
//mexPrintf( "VIP_GetStateCommand��%d \n" ,lResult);
if (lResult == VIP_Success)
{
    currentCSIState = lStateCommand;
}

// DelayInTicks = CountsPerSecond * SampleTimeInSeconds
DelayInTicks = (int)((__int64)gClockFrequency.QuadPart * lsampleTime);

boolean lwaitComplete = false;

if (LastRunCount.QuadPart != -1)
{
    while(!lwaitComplete)
    {
        if ( currentCSIState == VIP_State_Shutdown )
        {
            ssSetStopRequested(S, 1);
            mexPrintf( "VIP_State_Shutdown \n" );
        }

        switch( cInternalState )
        {
            case Inactive:
                break;
            case WaitingRestart:
                return;
                break;
            case SavingState:
                lwaitComplete = ProcessSavingState();
                mexPrintf( "SavingState \n" );
                return;
                break;
            case RestoringState:
                ProcessRestoringState();
                 mexPrintf( "RestoringState \n" );
                return;
                break;
            case WaitingContinue:
                ProcessSavingState2();
                 mexPrintf( "WaitingContinue \n" );
                return;
                break;
            default:
                break;
        }

        checkForHeld( lStateCommand );

        // Get the current tick count
        QueryPerformanceCounter(&CurrentCount);

        Delta = (int)(CurrentCount.QuadPart - LastRunCount.QuadPart);

        if ( (Delta >= DelayInTicks) && (currentCSIState != VIP_State_Held) )
        {
            // waited long enough exit loop
            lwaitComplete = true;
        }

        Sleep(1);
    }
}

if (lastCSIState != currentCSIState)
{
    mexPrintf( "VIP_SetState: %d \n",currentCSIState );
    VIP_SetState( lParticipantHandle, currentCSIState );
    lastCSIState = currentCSIState;
}

// Record tick count for next time
QueryPerformanceCounter(&LastRunCount);

//float DeltaInSec = ((float)Delta) / (__int64)gClockFrequency.QuadPart;
//mexPrintf("delta Seconds %f\n", DeltaInSec);
//int DeltaMS = (int)( DeltaInSec * 1000 );
//mexPrintf("delta MS %d\n", DeltaMS);

// Synchronise CSI data (sends/receives periodic data)
//lResult = VIP_SynchronizeData( lParticipantHandle, DeltaMS );
//if (lResult != VIP_Success)
//{
//   mexPrintf("VIP_SynchronizeData Error: %d\n", lResult);
//}
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////
// mdlTerminate
//
// Simulink callback. Made on closing the model.
//
static void mdlTerminate(SimStruct *S)
{
#ifndef VIP_COMPILED
if ( lParticipantHandle != VIP_InvalidHandle)
{
     mexPrintf( "VIP_Disconnect \n" );
    VIP_Disconnect( lParticipantHandle );
}
timeEndPeriod(1);
#endif
}

/* Simulink/Simulink Coder Interfaces */

#ifdef MATLAB_MEX_FILE /* Is this file being compiled as a MEX-file? */
#include "simulink.c" /* MEX-file interface mechanism */
#else
#include "cg_sfun.h" /* Code generation registration function */
#endif
