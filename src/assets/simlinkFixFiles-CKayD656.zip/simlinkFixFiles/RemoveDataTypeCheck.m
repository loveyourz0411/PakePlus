function b = RemoveDataTypeCheck(fileName)
% Remove the CheckDataTypes function from generated C++ file. This
% has to be removed if the number of inputs / outputs is large as it breaks
% the VC++ 10 compiler limit for 'for' loops.
% Fatal error C1061: compiler limit : blocks nested too deeply.
startMark = '/* Function: CheckDataTypes[^]*';
endMark = '/* Function: GetRTWEnvironmentMode';

b = false;
code = fileread(fileName);
% Find the begin/end markers.
chunk = regexp(code, strcat(startMark, endMark), 'match');
% Begin and end markers found?
if ~isempty(chunk)
    chunk = strrep(chunk, endMark, '');
    chunk = strtrim(chunk);
    code = strrep(code, strcat({'/* '}, chunk), 'static void CheckDataTypes(SimStruct *S){ return; }');

    fid = fopen(fileName,'w'); %Open file. This discards existing data!
    fwrite(fid, code{1});
    fclose(fid);   
    b = true;
end
